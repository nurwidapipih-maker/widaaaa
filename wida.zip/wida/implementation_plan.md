# Rencana Implementasi: Refaktorisasi Ombak Belajar ke Vanilla Modular (HTML/CSS/JS)

Refaktorisasi file monolitik tunggal [`prototype_ombak_belajar.html`](file:///d:/WEB/wida/prototype_ombak_belajar.html) (yang menggabungkan HTML, 228 baris CSS inline, dan script dasar) menjadi arsitektur web modern **Vanilla (HTML5, Modern CSS, ES6+ JavaScript)** yang modular, terstruktur per komponen, dan interaktif sesuai dengan [`spesifikasi-desain-figma.md`](file:///d:/WEB/wida/spesifikasi-desain-figma.md).

## User Review Required

> [!IMPORTANT]
> - Struktur ini murni **Vanilla Modern** (tanpa framework berat seperti React/Vue dan tanpa build step wajib), menggunakan **ES Modules (`import`/`export`)**.
> - Kode bisa langsung dijalankan menggunakan browser lokal / live server (misal `npx serve` atau ekstensi Live Server).
> - File lama [`prototype_ombak_belajar.html`](file:///d:/WEB/wida/prototype_ombak_belajar.html) akan tetap dipertahankan sebagai cadangan dan referensi asli, sementara kode baru akan ditempatkan di [`index.html`](file:///d:/WEB/wida/index.html) serta folder `css/` dan `js/`.

## Arsitektur & Pembagian Modul

Struktur folder baru yang akan dibuat:
```text
d:\WEB\wida\
├── index.html                   # Entry point semantik & wadah (mount points) komponen
├── css/
│   ├── variables.css            # Token desain (warna Figma, font, radius, shadow)
│   ├── base.css                 # Reset modern, tipografi, utility, animasi
│   ├── components/
│   │   ├── navbar.css           # Frosted glass navbar & badge status
│   │   ├── hero.css             # Radial gradient hero & kartu progres belajar
│   │   ├── why.css              # Grid kartu fitur keunggulan
│   │   ├── modules.css          # Grid kartu modul materi & status pill
│   │   ├── quiz.css             # Kartu kuis interaktif & feedback jawaban
│   │   ├── leaderboard.css      # Papan peringkat (sesuai spesifikasi Figma)
│   │   ├── modal.css            # Modal detail materi & kuis modul
│   │   └── cta-footer.css       # Banner CTA & footer
│   └── main.css                 # Master stylesheet (mengimpor semua berkas CSS)
├── js/
│   ├── data/
│   │   ├── modulesData.js       # Data 6 modul (judul, sesi, durasi, XP, status, materi)
│   │   ├── quizData.js          # Bank soal interaktif untuk kuis hero & kuis per modul
│   │   └── leaderboardData.js   # Data papan peringkat siswa (Figma spec point E)
│   ├── state/
│   │   └── store.js             # State management vanilla (XP, level, progres modul, event bus)
│   ├── components/
│   │   ├── Navbar.js            # Komponen navigasi + badge user + live XP counter
│   │   ├── Hero.js              # Komponen hero + kartu progres mingguan interaktif
│   │   ├── WhySection.js        # Komponen 3 pilar alasan belajar
│   │   ├── ModulesSection.js    # Grid modul materi (bisa diklik untuk buka modal detail)
│   │   ├── QuizSection.js       # Kuis interaktif real-time dengan feedback & penambahan XP
│   │   ├── LeaderboardSection.js# Tampilan papan peringkat (sesuai spesifikasi Figma)
│   │   ├── ModuleModal.js       # Dialog modal interaktif untuk baca materi & kuis modul
│   │   ├── CtaSection.js        # Komponen ajakan bertindak (CTA)
│   │   └── Footer.js            # Komponen footer semantik
│   └── app.js                   # Inisialisasi aplikasi, mounting komponen, & event listener
└── package.json                 # Skrip pembantu lokal (e.g. `npm run dev`)
```

---

## Proposed Changes

### 1. Struktur Styling (CSS Modular)
Memecah CSS monolitik dari `<style>` menjadi token dan stylesheet terpisah:
- **`css/variables.css`**: Token palet warna (Deep `#062B44`, Ocean `#0E4C6B`, Teal `#1C8C8C`, Coral `#FF6F59`, Seafoam, Sand, dll.), font (Fraunces & Space Grotesk), dan shadow.
- **`css/base.css`**: Global box-sizing, smooth scroll, animasi gelombang ombak, tombol standar (`btn-primary`, `btn-ghost`).
- **`css/components/*.css`**: Modul CSS terpisah untuk masing-masing bagian halaman dan komponen modal interaktif.
- **`css/main.css`**: `@import` semua modul CSS di atas agar terorganisir rapi.

### 2. Data & State Management (Vanilla JS)
- **`js/data/modulesData.js`**: Menyimpan array data objek modul 1–6 lengkap dengan deskripsi, materi singkat, status (`selesai`, `berjalan`, `terkunci`), durasi, dan XP.
- **`js/data/quizData.js`**: Menyimpan pertanyaan interaktif dengan penjelasan saat salah/benar.
- **`js/data/leaderboardData.js`**: Menyimpan daftar peringkat kelas XI budidaya perairan.
- **`js/state/store.js`**: Menyimpan state pengguna (XP saat ini, level nama nelayan muda, progres selesai). Memiliki fungsi `addXP()`, `completeModule()`, dan listener reaktif untuk memperbarui tampilan saat siswa menjawab kuis.

### 3. Komponen JavaScript (Component-based Vanilla JS)
Masing-masing komponen mengekspor fungsi render atau class mandiri yang menghasilkan elemen DOM/HTML semantik dan mengikat event listener lokal:
- **`Navbar.js`**: Menampilkan navigasi, logo SVG ombak, dan indikator level + XP pengguna yang reaktif.
- **`Hero.js`**: Menampilkan headline, CTA tombol, statistik angka, dan kartu progres minggu ini.
- **`WhySection.js`**: Menampilkan 3 kartu pilar keunggulan.
- **`ModulesSection.js`**: Merender 6 kartu modul secara dinamis dari data. Mengikat klik ke modal detail materi.
- **`QuizSection.js`**: Menghidupkan kuis interaktif dengan umpan balik langsung (correct/wrong animation) dan menambah XP ke user.
- **`LeaderboardSection.js`**: Mengimplementasikan papan peringkat dari spesifikasi Figma yang belum ada di prototipe lama.
- **`ModuleModal.js`**: Popup modal pop-up ketika modul diklik, memungkinkan membaca materi dan mencoba kuis modul.
- **`CtaSection.js` & `Footer.js`**: Bagian penutup halaman.

### 4. Entry Point & Script Utama
- **`index.html`**: Bersih dan ringkas, hanya memuat Google Fonts, stylesheet utama `main.css`, mount point (`#navbar-root`, `#hero-root`, `#why-root`, `#modules-root`, `#quiz-root`, `#leaderboard-root`, `#cta-root`, `#footer-root`, `#modal-root`), serta skrip modular `<script type="module" src="js/app.js"></script>`.
- **`js/app.js`**: Mengorkestrasikan pemanggilan render komponen ke dalam mount point, menghubungkan state store dengan komponen UI, dan mengaktifkan interaksi navigasi.

---

## Verification Plan

### Automated / Browser Verification
1. Jalankan server lokal atau gunakan browser subagent untuk membuka halaman.
2. Verifikasi tidak ada error di console browser (`console.error`).
3. Tes interaktivitas:
   - Klik kartu modul yang aktif: Membuka modal materi modul.
   - Jawab pertanyaan kuis di bagian kuis: Muncul umpan balik hijau/merah, XP bertambah di navbar & hero card secara dinamis.
   - Cek responsivitas tampilan (desktop dan mobile).
   - Pastikan visual, tipografi, dan warna sesuai dengan spesifikasi desain Figma.
