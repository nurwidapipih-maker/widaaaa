# 🌊 Ombak Belajar — Budidaya Perikanan SMK Kelas XI

> Media pembelajaran web interaktif berbasis gamifikasi untuk siswa SMK Jurusan Budidaya Perairan / Agribisnis Perikanan. Dilengkapi kurikulum 6 modul materi mendalam, evaluasi kuis kelulusan (*passing grade*), sistem leveling XP, papan peringkat kelas (*real-time leaderboard*), serta Panel Guru CMS mandiri.

[![Vanilla JS](https://img.shields.io/badge/JavaScript-Vanilla_ES6-F7DF1E?logo=javascript&logoColor=black)](https://developer.mozilla.org/en-US/docs/Web/JavaScript)
[![Vanilla CSS](https://img.shields.io/badge/CSS3-Modular_BEM-1572B6?logo=css3&logoColor=white)](https://developer.mozilla.org/en-US/docs/Web/CSS)
[![Firebase](https://img.shields.io/badge/Firebase-Firestore_Cloud_Sync-FFCA28?logo=firebase&logoColor=black)](https://firebase.google.com/)
[![Deployment](https://img.shields.io/badge/Deploy-Vercel_Ready-000000?logo=vercel&logoColor=white)](https://vercel.com/)
[![License: MIT](https://img.shields.io/badge/License-MIT-green.svg)](LICENSE)

---

## 🌟 Fitur Utama

- **🚀 Name Gate Onboarding**: Siswa memasukkan nama dan kelas saat pertama kali masuk; identitas tersimpan secara aman di sesi browser dan database.
- **📚 6 Modul Kurikulum Interaktif**:
  1. *Kualitas Air & Parameter Budidaya* (Suhu, pH, DO, Kekeruhan)
  2. *Manajemen Pakan & Formulasi Nutrisi* (FCR, Protein, Pelet)
  3. *Hama, Penyakit & Biosekuriti Kolam* (Bakteri, Jamur, Karantina)
  4. *Teknik Pembenihan & Fekunditas* (Seleksi Induk, Penetasan)
  5. *Sistem Akuakultur Modern: Bioflok & RAS* (Flok, Filter Biologis)
  6. *Pascapanen, Penanganan & Rantai Dingin* (Sortasi, Es Cair)
- **🎯 Evaluasi & Sequential Unlock**: Setiap modul memiliki 4 bab materi dan 3 soal evaluasi dengan *passing grade* 60%. Modul berikutnya hanya akan terbuka jika modul saat ini tuntas dikerjakan.
- **🏆 Gamifikasi 4 Level XP**:
  - Level 1: *Nelayan Pemula* (0–299 XP)
  - Level 2: *Nelayan Muda* (300–599 XP)
  - Level 3: *Pembudidaya Andal* (600–899 XP)
  - Level 4: *Master Budidaya* (900+ XP)
- **📊 Real-Time Leaderboard**: Papan peringkat kelas dinamis yang mengurutkan siswa riil berdasarkan XP dan jumlah modul yang diselesaikan.
- **⚙️ Panel Guru (Admin CMS)** di `/admin.html`: 5 tab kendali penuh tanpa coding untuk mengedit modul, menambah kuis, mengelola siswa, dan kustomisasi teks web.
- **☁️ Cloud Sync Firebase Firestore**: Sinkronisasi data dan peringkat antar siswa lintas perangkat (HP, laptop, tablet).
- **🎨 100% SVG Vector Icons**: Bersih, tajam, dan bebas dari ketergantungan emoji bawaan OS.

---

## 📂 Struktur Direktori

```
d:\WEB\wida/
├── index.html                     # Halaman utama aplikasi (Siswa)
├── admin.html                     # Dashboard CMS pengelolaan (Guru)
├── DOKUMENTASI.md                 # Dokumentasi teknis komprehensif & changelog
├── css/
│   ├── main.css                   # Aggregator stylesheet
│   ├── variables.css              # Design tokens & tema warna
│   ├── base.css                   # Reset, container, & utilitas
│   ├── admin.css                  # Stylesheet panel admin
│   └── components/                # Modular styling per komponen UI
└── js/
    ├── app.js                     # Entry point web siswa
    ├── admin.js                   # Kontroler admin CMS
    ├── config/                    # Kredensial Firebase Firestore
    ├── utils/icons.js             # Generator ikon SVG vektor presisi
    ├── data/                      # Bank data materi, kuis, dan teks
    ├── state/store.js             # Central state management (reaktif)
    └── components/                # Komponen antarmuka (ES6 Modules)
```

---

## 🚀 Cara Menjalankan Secara Lokal

Karena proyek ini menggunakan **JavaScript ES6 Modules**, buka proyek menggunakan server HTTP lokal (bukan membukanya langsung via double-click file):

### Menggunakan npx (Node.js):
```bash
npx -y serve . -l 3000
```
Buka browser di: `http://localhost:3000`

### Menggunakan Python (Tanpa Instalasi Tambahan):
```bash
python -m http.server 3000
```
Buka browser di: `http://localhost:3000`

---

## 👨‍🏫 Akses Panel Guru (CMS)

Untuk mengelola konten, mengakses bank soal, dan memantau siswa:
- Buka browser di: `http://localhost:3000/admin.html`
- Atau klik link **"Panel Guru CMS"** yang berada di footer halaman utama.

---

## 📖 Dokumentasi Lengkap & Riwayat Perubahan

Penjelasan teknis mendalam mengenai cara kerja setiap baris kode, fungsi file, dan kronologi evolusi dari file monolitik awal hingga ke arsitektur modular saat ini dapat dibaca pada berkas:
👉 **[DOKUMENTASI.md](DOKUMENTASI.md)**

---

## 📄 Lisensi

Proyek ini dirilis di bawah lisensi [MIT](LICENSE). Dikembangkan untuk kemajuan pendidikan kejuruan Budidaya Perairan Indonesia.
