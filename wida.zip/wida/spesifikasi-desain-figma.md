# Spesifikasi Desain — Ombak Belajar
### Panduan untuk Recreate Tampilan di Figma

Dokumen ini berisi seluruh detail visual (warna, tipografi, ukuran, komponen) dari prototipe yang sudah ada, supaya bisa kamu bangun ulang secara manual di Figma sebagai tahap "Design" dalam metodologi R&D-mu.

---

## 1. Palet Warna

| Nama Token | Kode Hex | Penggunaan |
|---|---|---|
| Deep (Navy Laut Dalam) | `#062B44` | Background hero, navbar, footer |
| Ocean | `#0E4C6B` | Gradasi sekunder, elemen gelap |
| Teal | `#1C8C8C` | Aksen utama, tombol sekunder, progress bar |
| Seafoam | `#E7F4EF` | Background kartu terang (why-card) |
| Sand | `#FBF6EC` | Background halaman utama |
| Coral | `#FF6F59` | Tombol CTA utama (primary button) |
| Coral Dark | `#E85A45` | Hover/active state tombol CTA |
| Ink (teks utama) | `#082333` | Warna teks judul & body di atas background terang |
| Mist (teks sekunder) | `#5D7C8A` | Teks deskripsi/subtitle |
| Putih | `#FFFFFF` | Teks di atas background gelap |

**Warna tambahan untuk status modul:**
- Hijau sukses (jawaban benar): `#2AA96B` / background `#E7F8EF`
- Kuning/emas (level, XP tag): `#F5C97A`, teks `#B4590F`

---

## 2. Tipografi

| Elemen | Font | Ukuran | Weight |
|---|---|---|---|
| Judul besar (H1 hero) | Fraunces (serif) | 44–56px desktop / 32px mobile | 600–700 |
| Judul section (H2) | Fraunces (serif) | 28–36px | 600 |
| Judul kartu (H3) | Fraunces (serif) | 18–20px | 600 |
| Body text | Space Grotesk (sans-serif) | 14–16px | 400 |
| Label kecil / tag | Space Grotesk | 12–13px | 600–700, huruf besar (uppercase) untuk eyebrow tag |

> Kedua font ini gratis dan tersedia di **Google Fonts** — tinggal cari "Fraunces" dan "Space Grotesk" di panel font Figma (aktifkan Google Fonts integration).

**Prinsip pasangan font:** Fraunces (serif berkarakter, sedikit playful, cocok kesan "ombak/organik") dipakai khusus judul; Space Grotesk (sans-serif modern, mudah dibaca) dipakai untuk semua teks isi dan UI.

---

## 3. Grid & Spacing

- **Lebar maksimum konten:** 1180px (desktop), di-center dengan margin otomatis
- **Padding halaman (kiri-kanan):** 6vw (kira-kira 80–96px di layar 1440px, 20px di mobile)
- **Jarak antar section:** 64–88px (top & bottom padding tiap section)
- **Radius sudut:**
  - Kartu besar (hero card, modal): 20–22px
  - Kartu modul: 18–20px
  - Tombol: 100px (pill/full rounded)
  - Kotak info kecil: 10–12px
- **Grid kolom modul:** 3 kolom (desktop) → 1 kolom (mobile, breakpoint di ~860px)

---

## 4. Spesifikasi per Komponen

### A. Navbar
- Height: ~64px, posisi sticky di atas
- Background: Deep (`#062B44`) dengan sedikit transparansi + blur (efek "frosted glass")
- Kiri: logo/brand (ikon ombak + teks "Ombak Belajar")
- Kanan: info nama siswa aktif + badge kecil "Mode Lokal"/"Mode Firebase"

### B. Hero Section
- Background: gradasi radial dari biru terang (`#0F5A78`) di pojok kiri atas menuju Deep/hitam kebiruan di kanan bawah
- Layout 2 kolom: teks (kiri, ±60% lebar) + kartu progres (kanan, ±40% lebar)
- Elemen teks: eyebrow badge kecil → judul besar → deskripsi → 3 angka statistik (jumlah modul, sesi, lencana)
- Kartu progres (kanan): badge level, progress bar horizontal (rounded), 3 baris daftar modul mini dengan status ikon (selesai/berjalan/terkunci)

### C. Kartu Modul (Module Card)
- Ukuran: mengikuti grid 3 kolom, rasio kartu kira-kira 1:1.1 (sedikit lebih tinggi dari lebar)
- Bagian atas kartu: blok warna gradasi (tinggi ±100–120px) dengan nomor urut modul (pojok kiri atas) dan status pill (pojok kanan atas: "Selesai" / "Berjalan" / "Terkunci")
- Bagian bawah kartu (putih): judul modul, deskripsi singkat 1-2 baris, baris meta (estimasi durasi + tag XP berwarna kuning/oranye)
- Kartu berstatus "Terkunci" dibuat 60% opacity dan cursor "not-allowed"

### D. Modal Kuis
- Card melayang di tengah layar dengan overlay gelap semi-transparan di belakang (`rgba(4,20,32,0.8)`)
- Header modal berwarna sesuai gradasi modul terkait, ada tombol close (✕) bulat di pojok kanan atas
- Body: paragraf materi, lalu daftar pertanyaan kuis — tiap pertanyaan berupa teks tebal + pilihan jawaban berbentuk tombol memanjang (rounded rectangle) yang bisa dipilih (highlight saat dipilih, hijau saat benar, merah saat salah setelah submit)
- Tombol "Kirim Jawaban" full-width, warna Teal

### E. Papan Peringkat (Leaderboard)
- Background gelap (Deep), tabel sederhana dengan 4 kolom: Nama, Kelas, Modul Selesai, XP
- Baris peringkat pertama diberi warna teks emas (`#F5C97A`) untuk menonjolkan

### F. Tombol (Button States)
- **Primary (CTA):** background Coral, teks putih, padding besar, full-rounded — dipakai untuk aksi utama ("Mulai Belajar", "Lanjutkan Modul")
- **Ghost/Secondary:** transparan, border putih tipis, dipakai untuk aksi sekunder di atas background gelap
- **Quiz option button:** kotak dengan border tipis, berubah warna sesuai state (netral/dipilih/benar/salah)

---

## 5. Struktur Halaman (Urutan Frame di Figma)

Buat sebagai frame terpisah, berurutan dari atas ke bawah dalam satu Figma Page:

1. `01 - Navbar`
2. `02 - Hero`
3. `03 - Kenapa Berbeda (3 kartu fitur)`
4. `04 - Peta Materi (grid 6 modul)`
5. `05 - Modal Kuis (frame terpisah, overlay)`
6. `06 - Papan Peringkat`
7. `07 - Footer`
8. `08 - Gate Login (modal nama & kelas)`

Sarankan juga membuat 2 ukuran frame per section: **Desktop (1440px)** dan **Mobile (375px)**, supaya bisa menunjukkan bahwa desain sudah dipikirkan responsif — ini nilai tambah di penilaian ahli media.

---

## 6. Ikon & Ilustrasi

Elemen visual bertema laut yang bisa ditambahkan di Figma (cari di library ikon seperti Phosphor Icons / Lucide, atau gambar bebas royalti):
- Gelombang/ombak (dekorasi pembatas antar section)
- Ikan, gelembung udara, rumput laut (ikon dekoratif di kartu modul)
- Ikon centang (✓), gembok (🔒), dan play (▶) untuk status modul

---

## 7. Cara Kerja di Figma (ringkas)

1. Buat file baru → set warna di atas sebagai **Color Styles**
2. Import font Fraunces & Space Grotesk, set sebagai **Text Styles** (H1, H2, H3, Body, Label)
3. Bangun komponen kecil dulu (tombol, tag, kartu modul) sebagai **Figma Components**, supaya bisa dipakai berulang secara konsisten
4. Susun frame per section sesuai urutan di atas
5. Setelah semua frame jadi, export sebagai gambar/PDF untuk dilampirkan sebagai bukti tahap "Design" di BAB III, dan gunakan sebagai acuan visual saat proses "Development" (coding).

---

*Dokumen ini adalah rujukan teknis internal untuk proses desainmu — sertakan proses pembuatan di Figma (screenshot progres, riwayat versi) sebagai bukti pendukung jika sewaktu-waktu ditanyakan proses desainnya oleh dosen pembimbing/penguji.*
