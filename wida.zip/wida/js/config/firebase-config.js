// Konfigurasi Cloud Firebase Firestore untuk Ombak Belajar
// Terhubung ke project 'ombak-belajar'
window.FIREBASE_CONFIG = {
  apiKey: "AIzaSyB3paunvM2qT-o0HS08xbC2hlvq8jyHx2c",
  authDomain: "ombak-belajar.firebaseapp.com",
  projectId: "ombak-belajar",
  storageBucket: "ombak-belajar.firebasestorage.app",
  messagingSenderId: "169821305056",
  appId: "1:169821305056:web:b684b6e6fadce21bbb3885",
  measurementId: "G-B3VW3MH8D6"
};
