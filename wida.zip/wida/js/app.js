/**
 * Entry Point Utama Aplikasi Web Vanilla
 * Menginisialisasi komponen modular dan memasang mount points ke dalam DOM.
 */
import { renderNameGate } from './components/NameGate.js';
import { renderNavbar } from './components/Navbar.js';
import { renderHero } from './components/Hero.js';
import { renderWhySection } from './components/WhySection.js';
import { renderModulesSection } from './components/ModulesSection.js';
import { renderQuizSection } from './components/QuizSection.js';
import { renderLeaderboardSection } from './components/LeaderboardSection.js';
import { renderModuleModal } from './components/ModuleModal.js';
import { renderCtaSection } from './components/CtaSection.js';
import { renderFooter } from './components/Footer.js';

document.addEventListener('DOMContentLoaded', () => {
  // 1. Onboarding / Name Gate Siswa
  const gateMount = document.getElementById('gate-mount');
  if (gateMount) renderNameGate(gateMount);

  // 2. Navigasi Utama
  const navbarMount = document.getElementById('navbar-mount');
  if (navbarMount) renderNavbar(navbarMount);

  // 3. Hero & Progres Siswa
  const heroMount = document.getElementById('hero-mount');
  if (heroMount) renderHero(heroMount);

  // 4. Kenapa Berbeda
  const whyMount = document.getElementById('why-mount');
  if (whyMount) renderWhySection(whyMount);

  // 5. Peta Materi Modul
  const modulesMount = document.getElementById('modules-mount');
  if (modulesMount) renderModulesSection(modulesMount);

  // 6. Kuis Interaktif Beranda
  const quizMount = document.getElementById('quiz-mount');
  if (quizMount) renderQuizSection(quizMount);

  // 7. Papan Peringkat (Leaderboard)
  const leaderboardMount = document.getElementById('leaderboard-mount');
  if (leaderboardMount) renderLeaderboardSection(leaderboardMount);

  // 8. CTA Penutup
  const ctaMount = document.getElementById('cta-mount');
  if (ctaMount) renderCtaSection(ctaMount);

  // 9. Footer
  const footerMount = document.getElementById('footer-mount');
  if (footerMount) renderFooter(footerMount);

  // 10. Dialog Modal Modul
  const modalMount = document.getElementById('modal-mount');
  if (modalMount) renderModuleModal(modalMount);

  console.log('[Ombak Belajar] Berhasil dimuat dengan arsitektur modular Vanilla JS & CSS.');
});
