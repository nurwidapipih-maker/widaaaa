/**
 * Komponen Footer
 * Footer semantik dengan metadata hak cipta dan tombol cepat ke Panel Guru (Admin).
 */
import { store } from '../state/store.js';
import { icons } from '../utils/icons.js';

export function renderFooter(mountEl) {
  function renderContent(state) {
    const footer = state.siteContent.footer;

    mountEl.innerHTML = `
      <footer>
        <div class="footer-inner">
          <div class="footer-brand">
            <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M2 16C4 13 6 13 8 16C10 19 12 19 14 16C16 13 18 13 20 16C21 17.5 22 17.5 22 17.5" stroke="#7FE0C9" stroke-width="2" stroke-linecap="round"/>
              <path d="M2 11C4 8 6 8 8 11C10 14 12 14 14 11C16 8 18 8 20 11C21 12.5 22 12.5 22 12.5" stroke="#1C8C8C" stroke-width="2" stroke-linecap="round"/>
            </svg>
            <span>${footer.brandText}</span>
          </div>

          <div class="footer-meta">
            <span class="footer-badge">${footer.badgeText}</span>
            <span>${footer.noticeText}</span>
            <a href="admin.html" style="color: var(--teal-light); text-decoration: underline; font-weight: 600; display: inline-flex; align-items: center; gap: 6px;">
              ${icons.settings(14)}
              <span>Kelola Konten (Panel Guru)</span>
            </a>
          </div>
        </div>
      </footer>
    `;
  }

  renderContent(store.getState());

  store.subscribe((newState) => {
    renderContent(newState);
  });
}
