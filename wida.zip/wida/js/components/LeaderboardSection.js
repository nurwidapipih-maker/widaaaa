/**
 * Komponen LeaderboardSection
 * Implementasi Papan Peringkat Siswa dari Spesifikasi Desain Figma (Bagian E).
 */
import { store } from '../state/store.js';
import { icons } from '../utils/icons.js';

export function renderLeaderboardSection(mountEl) {
  function renderTable(state) {
    // Urutkan siswa berdasarkan perolehan XP tertinggi
    const sortedLeaderboard = [...state.leaderboard].sort((a, b) => b.xp - a.xp);
    const totalModules = state.modules.length;

    const emptyMessage = sortedLeaderboard.length === 0
      ? `<tr><td colspan="5" style="text-align:center; padding:40px 20px; color:#A9C9CE; font-style:italic;">
           Belum ada siswa yang mendaftar. Masukkan nama di halaman utama untuk mulai belajar.
         </td></tr>`
      : '';

    mountEl.innerHTML = `
      <section class="leaderboard-section" id="leaderboard">
        <div class="wrap leaderboard-container">
          <div class="section-head" style="text-align: center; margin-bottom: 36px;">
            <span class="section-tag" style="color: var(--gold); display: inline-flex; align-items: center; gap: 6px;">
              ${icons.trophy(16)}
              <span>Papan Prestasi</span>
            </span>
            <h2 style="color: white;">Peringkat Kelas XI Budidaya Perairan</h2>
            <p style="color: #A9C9CE; margin: 10px auto 0; max-width: 500px;">
              Selesaikan modul dan kuis untuk meningkatkan reputasi belajarmu di angkatan.
            </p>
            <div style="margin-top: 10px;">
              ${store.firebaseActive ? `
                <span style="display:inline-flex; align-items:center; gap:6px; font-size:0.75rem; background:rgba(127,224,201,0.18); color:#7FE0C9; padding:4px 12px; border-radius:100px; font-weight:600;">
                  ${icons.check(12)} Cloud Sync Firebase Aktif (Peringkat Live Seluruh Siswa)
                </span>
              ` : `
                <span style="display:inline-flex; align-items:center; gap:6px; font-size:0.75rem; background:rgba(255,255,255,0.08); color:#A9C9CE; padding:4px 12px; border-radius:100px;">
                  Mode Lokal (Data tersimpan di browser). Guru dapat menghubungkan Firebase di Panel Guru.
                </span>
              `}
            </div>
          </div>

          <div class="leaderboard-card">
            <table class="leaderboard-table">
              <thead>
                <tr>
                  <th style="width: 70px;">Rank</th>
                  <th>Nama Siswa</th>
                  <th>Kelas</th>
                  <th style="text-align: center;">Modul Selesai</th>
                  <th style="text-align: right;">Total XP</th>
                </tr>
              </thead>
              <tbody>
                ${emptyMessage || sortedLeaderboard.map((item, index) => {
                  const rank = index + 1;
                  const isFirst = rank === 1;
                  const isCurrent = item.isCurrent;

                  let rankContent = rank;
                  if (rank <= 3) {
                    rankContent = `
                      <span style="display:inline-flex; align-items:center; justify-content:center; gap:3px;">
                        ${icons.medal(rank, 16)}
                        <span>${rank}</span>
                      </span>
                    `;
                  }

                  return `
                    <tr class="${isFirst ? 'rank-1' : ''} ${isCurrent ? 'current-user' : ''}">
                      <td>
                        <span class="rank-badge">${rankContent}</span>
                      </td>
                      <td>
                        <div class="student-col">
                          <div class="student-avatar">${item.name.charAt(0)}</div>
                          <div>
                            <strong>${item.name}</strong>
                            ${isCurrent ? '<span class="student-badge-me">Kamu</span>' : ''}
                          </div>
                        </div>
                      </td>
                      <td>${item.class}</td>
                      <td style="text-align: center;">${item.completedModules} / ${totalModules}</td>
                      <td style="text-align: right;" class="xp-cell">
                        <span style="display:inline-flex; align-items:center; gap:4px;">
                          ${icons.star(13)}
                          <span>${item.xp} XP</span>
                        </span>
                      </td>
                    </tr>
                  `;
                }).join('')}
              </tbody>
            </table>
          </div>
        </div>
      </section>
    `;
  }

  // Render awal
  renderTable(store.getState());

  // Reaktif terhadap perubahan XP siswa
  store.subscribe((newState) => {
    renderTable(newState);
  });
}
