/**
 * Komponen Navbar
 * Menampilkan logo, tautan navigasi, profil siswa aktif (nama, kelas, XP, mode flag), dan tombol Ganti Siswa.
 * (Dileburkan dari ombak_belajar_fungsional.html)
 */
import { store } from '../state/store.js';
import { icons } from '../utils/icons.js';

export function renderNavbar(mountEl) {
  function render(state) {
    const student = state.student;
    const modeText = store.firebaseActive ? 'Mode Firebase' : 'Mode Lokal';

    mountEl.innerHTML = `
      <nav class="nav" id="main-nav">
        <div class="brand" id="nav-brand">
          <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M2 16C4 13 6 13 8 16C10 19 12 19 14 16C16 13 18 13 20 16C21 17.5 22 17.5 22 17.5" stroke="#7FE0C9" stroke-width="2" stroke-linecap="round"/>
            <path d="M2 11C4 8 6 8 8 11C10 14 12 14 14 11C16 8 18 8 20 11C21 12.5 22 12.5 22 12.5" stroke="#1C8C8C" stroke-width="2" stroke-linecap="round"/>
          </svg>
          Ombak Belajar
        </div>

        <div class="nav-links" id="nav-menu">
          <a href="#modul">Materi</a>
          <a href="#kuis">Kuis</a>
          <a href="#progres">Progres</a>
          <a href="#leaderboard">Peringkat</a>
          <a href="admin.html" style="color: var(--teal-light); font-weight: 600; display: inline-flex; align-items: center; gap: 6px;">
            ${icons.settings(15)}
            <span>Panel Guru</span>
          </a>
        </div>

        <div class="nav-right">
          <!-- Profil Siswa Aktif (Student Chip dari fungsional) -->
          <div class="user-badge" id="btn-user-badge" title="Klik untuk mengganti akun siswa" style="cursor: pointer;">
            <div class="user-avatar" id="nav-avatar">${(student.name || 'S').charAt(0).toUpperCase()}</div>
            <div class="user-info">
              <span class="user-name" id="nav-user-name">
                ${student.name ? `${student.name} · ${student.class || '-'}` : 'Pilih Nama Siswa'}
              </span>
              <span class="user-xp" style="display: inline-flex; align-items: center; gap: 6px;">
                <span style="display: inline-flex; align-items: center; gap: 3px;">
                  ${icons.star(12)}
                  <span id="nav-user-xp">${student.xp || 0} XP</span>
                </span>
                <span class="mode-flag" style="font-size: 0.68rem; padding: 2px 8px; border-radius: 100px; background: rgba(255,255,255,0.14); color: #BFE3E0;">
                  ${modeText}
                </span>
              </span>
            </div>
          </div>

          <button class="nav-cta" id="nav-switch-student-btn" style="background: rgba(255,255,255,0.12); color: white; border: 1px solid rgba(255,255,255,0.25); padding: 8px 16px; font-size: 0.82rem;">
            Ganti Siswa
          </button>

          <button class="mobile-toggle" id="mobile-toggle-btn" aria-label="Toggle Menu">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <line x1="3" y1="12" x2="21" y2="12"></line>
              <line x1="3" y1="6" x2="21" y2="6"></line>
              <line x1="3" y1="18" x2="21" y2="18"></line>
            </svg>
          </button>
        </div>
      </nav>
    `;

    const brandEl = mountEl.querySelector('#nav-brand');
    brandEl?.addEventListener('click', () => {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    });

    const mobileToggle = mountEl.querySelector('#mobile-toggle-btn');
    const navMenu = mountEl.querySelector('#nav-menu');
    mobileToggle?.addEventListener('click', () => {
      navMenu.classList.toggle('open');
    });

    // Tombol ganti siswa / klik chip membuka Name Gate
    mountEl.querySelector('#btn-user-badge')?.addEventListener('click', () => {
      store.openGate();
    });
    mountEl.querySelector('#nav-switch-student-btn')?.addEventListener('click', () => {
      store.openGate();
    });
  }

  render(store.getState());

  store.subscribe((newState) => {
    render(newState);
  });
}
