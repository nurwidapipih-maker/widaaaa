/**
 * Komponen CtaSection
 * Banner ajakan bertindak (CTA) membaca data dinamis dari store.
 */
import { store } from '../state/store.js';

export function renderCtaSection(mountEl) {
  function renderContent(state) {
    const cta = state.siteContent.cta;

    mountEl.innerHTML = `
      <div class="cta-wrapper">
        <div class="cta">
          <div>
            <h2>${cta.title}</h2>
            <p>${cta.lead}</p>
          </div>
          <button class="btn-primary" id="cta-continue-btn" style="box-shadow: 0 10px 24px -6px rgba(0,0,0,0.3);">
            ${cta.btnText}
          </button>
        </div>
      </div>
    `;

    mountEl.querySelector('#cta-continue-btn')?.addEventListener('click', () => {
      const activeMod = store.getState().modules.find(m => m.status === 'berjalan') || store.getState().modules[0];
      if (activeMod) store.setActiveModule(activeMod.id);
    });
  }

  renderContent(store.getState());

  store.subscribe((newState) => {
    renderContent(newState);
  });
}
