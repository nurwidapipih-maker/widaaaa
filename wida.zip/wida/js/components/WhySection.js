/**
 * Komponen WhySection
 * Menjelaskan tiga pilar keunggulan metodologi pembelajaran Ombak Belajar.
 * Membaca data dinamis dari store (dapat diedit melalui Panel Admin).
 */
import { store } from '../state/store.js';

export function renderWhySection(mountEl) {
  function renderContent(state) {
    const whyData = state.siteContent.why;

    mountEl.innerHTML = `
      <section class="why">
        <div class="wrap">
          <div class="section-head">
            <span class="section-tag">${whyData.tag}</span>
            <h2>${whyData.title}</h2>
            <p>${whyData.lead}</p>
          </div>

          <div class="why-grid">
            ${whyData.cards.map(c => `
              <div class="why-card">
                <span class="num">${c.num}</span>
                <h3>${c.title}</h3>
                <p>${c.desc}</p>
              </div>
            `).join('')}
          </div>
        </div>
      </section>
    `;
  }

  renderContent(store.getState());

  store.subscribe((newState) => {
    renderContent(newState);
  });
}
