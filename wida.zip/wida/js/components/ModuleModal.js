/**
 * Komponen ModuleModal
 * Modal materi lengkap (multi-paragraf) dan mesin evaluasi kuis 3 soal per modul dengan passing grade.
 * (Dileburkan dari ombak_belajar_fungsional.html)
 */
import { store } from '../state/store.js';
import { icons } from '../utils/icons.js';

export function renderModuleModal(mountEl) {
  let selectedAnswers = {};
  let hasSubmitted = false;

  mountEl.innerHTML = `
    <div class="modal-overlay" id="module-modal-overlay">
      <div class="modal-dialog" id="module-modal-dialog" style="max-width: 680px; max-height: 90vh;">
        <!-- Header, Body, Footer akan di-inject dinamis -->
      </div>
    </div>
  `;

  const overlay = mountEl.querySelector('#module-modal-overlay');
  const dialog = mountEl.querySelector('#module-modal-dialog');

  function closeModal() {
    overlay.classList.remove('open');
    store.setActiveModule(null);
  }

  overlay.addEventListener('click', (e) => {
    if (e.target === overlay) closeModal();
  });

  window.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && overlay.classList.contains('open')) {
      closeModal();
    }
  });

  function openModule(moduleId) {
    const mod = store.getState().modules.find(m => m.id === moduleId);
    if (!mod) return;

    selectedAnswers = {};
    hasSubmitted = false;
    const isDone = store.getState().student.completed.includes(mod.id);

    // Ambil konten paragraf & soal kuis
    const paragraphs = mod.content || (mod.materi?.intro ? [mod.materi.intro, ...(mod.materi.keyPoints || [])] : ['Materi modul.']);
    
    // Normalisasi daftar pertanyaan
    let questions = mod.questions;
    if (!questions && mod.materi?.quiz) {
      const q = mod.materi.quiz;
      const cIdx = q.options.findIndex(o => o.isCorrect);
      questions = [{
        q: q.question,
        options: q.options.map(o => o.text),
        correct: cIdx !== -1 ? cIdx : 0
      }];
    }
    if (!questions) questions = [];

    dialog.innerHTML = `
      <div class="modal-header" style="background: ${mod.gradient};">
        <div class="modal-header-text">
          <div class="modal-header-meta">
            <span>MODUL ${mod.seq}</span>
            <span>·</span>
            <span style="display:inline-flex; align-items:center; gap:4px;">
              ${icons.clock(13)}
              <span>${mod.sessions} SESI (${mod.duration})</span>
            </span>
            <span>·</span>
            <span style="display:inline-flex; align-items:center; gap:4px;">
              ${icons.star(12)}
              <span>+${mod.xp} XP</span>
            </span>
          </div>
          <h3 style="margin-top: 6px; font-size: 1.4rem;">${mod.title}</h3>
        </div>
        <button class="modal-close-btn" id="btn-modal-close" aria-label="Tutup">
          ${icons.close(16)}
        </button>
      </div>

      <div class="modal-body" style="padding: 28px; overflow-y: auto;">
        <!-- Konten Paragraf Materi -->
        <div class="modal-materi">
          <h4 style="display: flex; align-items: center; gap: 8px; margin-bottom: 14px; font-size: 1.1rem;">
            ${icons.book(18)}
            <span>Materi Pembelajaran</span>
          </h4>
          <div style="display: flex; flex-direction: column; gap: 12px; color: #2B3F4A; font-size: 0.94rem; line-height: 1.65;">
            ${paragraphs.map(p => `<p style="margin: 0;">${p}</p>`).join('')}
          </div>
        </div>

        <!-- Blok Kuis Evaluasi -->
        <div class="modal-quiz-block" style="margin-top: 24px; border-top: 1px dashed #DDE7E5; padding-top: 20px;">
          <h5 style="display: flex; align-items: center; gap: 8px; font-size: 1.05rem; margin-bottom: 14px;">
            ${icons.target(18)}
            <span>${isDone ? 'Kuis (Sudah Kamu Tuntaskan)' : 'Uji Pemahaman Modul'}</span>
          </h5>

          <div id="quiz-items-list" style="display: flex; flex-direction: column; gap: 20px;">
            ${questions.map((qItem, qi) => `
              <div class="qitem" style="background: white; border: 1px solid #DFEDE8; border-radius: 12px; padding: 16px;">
                <div style="font-weight: 600; color: var(--deep); margin-bottom: 10px; font-size: 0.92rem;">
                  ${qi + 1}. ${qItem.q}
                </div>
                <div class="qopts" style="display: flex; flex-direction: column; gap: 8px;">
                  ${qItem.options.map((optText, oi) => `
                    <button type="button" class="modal-opt-btn" data-q="${qi}" data-o="${oi}">
                      ${optText}
                    </button>
                  `).join('')}
                </div>
              </div>
            `).join('')}
          </div>

          <!-- Kotak Hasil Kelulusan -->
          <div id="quiz-result-box" style="display: none; margin-top: 20px; padding: 18px; border-radius: 14px; font-size: 0.92rem; line-height: 1.6;"></div>
        </div>
      </div>

      <div class="modal-footer" style="padding: 18px 28px; background: #FAF7F0; border-top: 1px solid #EAE1CE; display: flex; justify-content: flex-end;">
        <button class="modal-submit-btn" id="btn-submit-module-quiz">
          ${isDone ? 'Tutup Materi' : 'Kirim Jawaban Kuis →'}
        </button>
      </div>
    `;

    // Pasang tombol close
    dialog.querySelector('#btn-modal-close').addEventListener('click', closeModal);

    const submitBtn = dialog.querySelector('#btn-submit-module-quiz');
    const resultBox = dialog.querySelector('#quiz-result-box');
    const optButtons = dialog.querySelectorAll('.modal-opt-btn');

    if (isDone) {
      submitBtn.onclick = closeModal;
      submitBtn.style.background = 'var(--teal)';
      submitBtn.textContent = 'Tutup Materi';
      return;
    }

    // Pasang pilihan jawaban pada tiap nomor soal
    optButtons.forEach(btn => {
      btn.addEventListener('click', () => {
        if (hasSubmitted) return;

        const qi = parseInt(btn.getAttribute('data-q'), 10);
        const oi = parseInt(btn.getAttribute('data-o'), 10);

        selectedAnswers[qi] = oi;

        dialog.querySelectorAll(`.modal-opt-btn[data-q="${qi}"]`).forEach(b => {
          b.classList.remove('selected');
        });
        btn.classList.add('selected');
      });
    });

    // Pasang submit evaluasi
    submitBtn.addEventListener('click', async () => {
      if (hasSubmitted) {
        closeModal();
        return;
      }

      const total = questions.length;
      const answeredCount = Object.keys(selectedAnswers).length;
      if (answeredCount < total) {
        alert('Mohon jawab seluruh soal kuis terlebih dahulu.');
        return;
      }

      hasSubmitted = true;

      // Evaluasi dan beri warna pada tombol
      questions.forEach((qItem, qi) => {
        const chosen = selectedAnswers[qi];
        dialog.querySelectorAll(`.modal-opt-btn[data-q="${qi}"]`).forEach(b => {
          b.disabled = true;
          const oi = parseInt(b.getAttribute('data-o'), 10);
          if (oi === qItem.correct) {
            b.classList.add('correct');
          } else if (oi === chosen) {
            b.classList.add('wrong');
          }
        });
      });

      const res = await store.submitModuleQuiz(mod.id, selectedAnswers);
      if (!res) return;

      resultBox.style.display = 'block';
      setTimeout(() => {
        resultBox.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
      }, 50);

      if (res.passed) {
        resultBox.style.background = 'var(--success-bg)';
        resultBox.style.color = '#0E663B';
        resultBox.style.border = '1px solid #B4F5D3';
        resultBox.innerHTML = `
          <strong>Selamat! Skor ${res.score}/${res.total} — Modul ini tuntas!</strong><br>
          ${res.xpAwarded > 0 ? `+${res.xpAwarded} XP telah ditambahkan ke profilmu, dan modul berikutnya otomatis terbuka.` : 'Modul ini sudah pernah kamu tuntaskan sebelumnya.'}
        `;

        submitBtn.innerHTML = `Selesai & Lanjutkan Belajar ${icons.check(14)}`;
        submitBtn.style.background = 'var(--success)';
        submitBtn.onclick = closeModal;
      } else {
        resultBox.style.background = '#FFF1EF';
        resultBox.style.color = '#B52F1D';
        resultBox.style.border = '1px solid #FFD4CD';
        resultBox.innerHTML = `
          <strong>Skor ${res.score}/${res.total} — Belum mencapai batas kelulusan (minimal 60%).</strong><br>
          Coba baca kembali materinya, lalu buka ulang modul ini untuk mengulang kuis.
        `;

        submitBtn.textContent = 'Tutup & Ulangi Nanti';
        submitBtn.style.background = 'var(--coral)';
        submitBtn.onclick = closeModal;
      }
    });

    overlay.classList.add('open');
  }

  store.subscribe((state) => {
    if (state.activeModuleId) {
      openModule(state.activeModuleId);
    }
  });
}
