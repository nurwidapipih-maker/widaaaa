/**
 * Komponen QuizSection
 * Kuis interaktif dengan umpan balik langsung dan penambahan XP ke pengguna.
 * Membaca bank kuis dinamis dari store (dapat diedit melalui Panel Admin).
 */
import { store } from '../state/store.js';
import { icons } from '../utils/icons.js';

export function renderQuizSection(mountEl) {
  let currentIdx = 0;
  let hasAnswered = false;

  function renderCard() {
    const quizzes = store.getState().quizzes;
    if (!quizzes || quizzes.length === 0) {
      mountEl.innerHTML = '';
      return;
    }

    if (currentIdx >= quizzes.length) currentIdx = 0;
    const q = quizzes[currentIdx];

    mountEl.innerHTML = `
      <section class="quiz-section" id="kuis">
        <div class="wrap quiz-wrap">
          <div class="copy">
            <span class="section-tag">Coba Interaktif</span>
            <h2>Kuis singkat, bukan ujian yang bikin gugup</h2>
            <p>Tiap sesi ditutup kuis 3–5 soal untuk mengecek pemahaman — bisa dicoba ulang tanpa nilai turun.</p>
            
            <div class="mini-features">
              <div class="mini-feature-item">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none">
                  <path d="M20 6L9 17l-5-5" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
                </svg>
                <span>Jawaban salah tetap dapat penjelasan singkat, bukan sekadar "salah"</span>
              </div>
              <div class="mini-feature-item">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none">
                  <path d="M20 6L9 17l-5-5" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
                </svg>
                <span>XP tetap didapat dari usaha mencoba, bukan cuma dari nilai sempurna</span>
              </div>
              <div class="mini-feature-item">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none">
                  <path d="M20 6L9 17l-5-5" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
                </svg>
                <span>Bisa diulang kapan pun tanpa rasa "gagal"</span>
              </div>
            </div>
          </div>

          <div class="quiz-card">
            <div class="quiz-card-header">
              <span class="qtag">${q.tag}</span>
              <span class="quiz-indicator">Soal ${currentIdx + 1} dari ${quizzes.length}</span>
            </div>

            <h3 id="quiz-question-title">${q.question}</h3>

            <div class="quiz-options" id="quiz-options-container">
              ${q.options.map((opt, i) => `
                <button class="qopt" data-index="${i}" ${hasAnswered ? 'disabled' : ''}>
                  <span>${opt.text}</span>
                  <span class="opt-indicator"></span>
                </button>
              `).join('')}
            </div>

            <div class="qfeedback" id="quiz-feedback-box"></div>

            <div class="quiz-footer">
              <div class="qxp" style="display: inline-flex; align-items: center; gap: 6px;">
                ${icons.star(14)}
                <span>+${q.xpReward} XP untuk setiap percobaan</span>
              </div>
              <button class="btn-next-quiz" id="btn-next-quiz" style="display: ${hasAnswered ? 'inline-flex' : 'none'}; align-items: center; gap: 6px;">
                ${currentIdx + 1 < quizzes.length ? 'Soal Berikutnya →' : `${icons.refresh(13)} Ulangi Kuis`}
              </button>
            </div>
          </div>
        </div>
      </section>
    `;

    // Pasang Event Listener Pilihan Jawaban
    const optionBtns = mountEl.querySelectorAll('.qopt');
    const feedbackBox = mountEl.querySelector('#quiz-feedback-box');
    const nextBtn = mountEl.querySelector('#btn-next-quiz');

    optionBtns.forEach((btn) => {
      btn.addEventListener('click', () => {
        if (hasAnswered) return;
        hasAnswered = true;

        const selectedIndex = parseInt(btn.getAttribute('data-index'), 10);
        const selectedOption = q.options[selectedIndex];

        optionBtns.forEach(b => b.disabled = true);

        if (selectedOption.isCorrect) {
          btn.classList.add('correct');
          btn.querySelector('.opt-indicator').innerHTML = icons.check(14, 2.5);
          feedbackBox.textContent = q.feedbackCorrect;
          feedbackBox.className = 'qfeedback show';
        } else {
          btn.classList.add('wrong');
          btn.querySelector('.opt-indicator').innerHTML = icons.close(14, 2.5);
          
          q.options.forEach((opt, idx) => {
            if (opt.isCorrect) {
              optionBtns[idx].classList.add('correct');
              optionBtns[idx].querySelector('.opt-indicator').innerHTML = icons.check(14, 2.5);
            }
          });

          feedbackBox.textContent = q.feedbackWrong;
          feedbackBox.className = 'qfeedback show is-wrong';
        }

        store.addXP(q.xpReward);
        nextBtn.style.display = 'inline-flex';
      });
    });

    nextBtn.addEventListener('click', () => {
      hasAnswered = false;
      currentIdx = (currentIdx + 1) % quizzes.length;
      renderCard();
    });
  }

  renderCard();

  store.subscribe(() => {
    if (!hasAnswered) {
      renderCard();
    }
  });
}
