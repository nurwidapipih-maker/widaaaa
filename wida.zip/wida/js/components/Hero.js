/**
 * Komponen Hero
 * Headline utama, kartu progres interaktif, statistik pembelajaran, dan gelombang SVG.
 * Menampilkan kalkulasi progres riil siswa dan level 4 tingkat (Nelayan Pemula s/d Master Budidaya).
 * (Dileburkan dari ombak_belajar_fungsional.html)
 */
import { store } from '../state/store.js';
import { icons } from '../utils/icons.js';

export function renderHero(mountEl) {
  function renderContent(state) {
    const heroData = state.siteContent.hero;
    const student = state.student;
    const totalModules = state.modules.length;
    const completedCount = (student.completed || []).length;
    const pct = totalModules > 0 ? Math.round((completedCount / totalModules) * 100) : 0;
    const levelInfo = store.getCurrentLevel();

    const cleanBadgeText = (heroData.badge || '').replace(/[^\x00-\x7F\w\s·.-]/g, '').trim();

    mountEl.innerHTML = `
      <header class="hero" id="progres">
        <div class="hero-inner">
          <div>
            <div class="eyebrow-badge" id="hero-badge">
              ${icons.fish(16)}
              <span>${cleanBadgeText || 'Budidaya Perairan · Kelas XI'}</span>
            </div>
            <h1 id="hero-title">${heroData.title}</h1>
            <p class="lead" id="hero-lead">
              ${heroData.lead}
            </p>
            
            <div class="hero-actions">
              <button class="btn-primary" id="hero-continue-btn">${heroData.btnPrimary}</button>
              <button class="btn-ghost" id="hero-explore-btn">${heroData.btnGhost}</button>
            </div>

            <div class="hero-stats">
              <div><strong>${completedCount}/${totalModules}</strong><span>Modul selesai</span></div>
              <div><strong>${student.xp || 0}</strong><span>Total XP</span></div>
              <div><strong>Level ${levelInfo.level}</strong><span>${levelInfo.title}</span></div>
            </div>
          </div>

          <!-- Kartu Progres Siswa -->
          <div class="hero-card" id="hero-progress-card">
            <div class="hero-card-top">
              <span>Progresmu</span>
              <div class="level-pill" id="hero-level-pill">${levelInfo.title}</div>
            </div>

            <div class="wave-progress">
              <div class="wave-progress-bar" id="hero-progress-fill" style="width: ${pct}%;"></div>
            </div>

            <div class="progress-label">
              <span id="hero-progress-text">${pct}% modul selesai (${completedCount}/${totalModules})</span>
              <span id="hero-xp-label" style="display:inline-flex; align-items:center; gap:4px;">
                ${icons.star(12)}
                <span>${student.xp || 0} XP</span>
              </span>
            </div>

            <div class="module-mini-list" id="hero-mini-modules">
              <!-- Diisi secara dinamis -->
            </div>
          </div>
        </div>

        <!-- Gelombang Ombak SVG Dekoratif -->
        <div class="hero-waves">
          <svg viewBox="0 0 1440 90" preserveAspectRatio="none">
            <path d="M0,40 C240,90 480,0 720,30 C960,60 1200,10 1440,45 L1440,90 L0,90 Z" fill="#FBF6EC"></path>
          </svg>
        </div>
      </header>
    `;

    // Render Mini Module Items berdasarkan progres riil siswa
    const miniContainer = mountEl.querySelector('#hero-mini-modules');
    if (miniContainer) {
      const sampleModules = state.modules.slice(0, 3);
      miniContainer.innerHTML = sampleModules.map((m) => {
        const status = store.getModuleStatus(m.id);
        let iconHtml = icons.lock(14);
        let iconClass = '';
        let subText = m.summary || m.description;

        if (status === 'selesai') {
          iconHtml = icons.check(14, 2.5);
          iconClass = 'done';
          subText = `Selesai · +${m.xp} XP`;
        } else if (status === 'berjalan') {
          iconHtml = icons.play(11);
          iconClass = 'active';
          subText = `Terbuka untuk dipelajari`;
        } else {
          iconHtml = icons.lock(14);
          iconClass = '';
          subText = 'Selesaikan modul sebelumnya';
        }

        return `
          <div class="module-mini" style="cursor: ${status !== 'terkunci' ? 'pointer' : 'default'};" data-id="${m.id}">
            <div class="mod-icon ${iconClass}">${iconHtml}</div>
            <div class="mtext">
              <div class="mtitle">${m.title}</div>
              <div class="msub">${subText}</div>
            </div>
          </div>
        `;
      }).join('');

      miniContainer.querySelectorAll('.module-mini').forEach(item => {
        item.addEventListener('click', () => {
          const id = parseInt(item.getAttribute('data-id'), 10);
          if (store.getModuleStatus(id) !== 'terkunci') {
            store.setActiveModule(id);
          }
        });
      });
    }

    // Event Listeners
    mountEl.querySelector('#hero-continue-btn')?.addEventListener('click', () => {
      // Cari modul yang sedang terbuka/berjalan pertama yang belum selesai
      const nextOpenMod = state.modules.find(m => store.getModuleStatus(m.id) === 'berjalan') || state.modules[0];
      if (nextOpenMod) store.setActiveModule(nextOpenMod.id);
    });

    mountEl.querySelector('#hero-explore-btn')?.addEventListener('click', () => {
      document.querySelector('#modul')?.scrollIntoView({ behavior: 'smooth' });
    });
  }

  renderContent(store.getState());

  store.subscribe((newState) => {
    renderContent(newState);
  });
}
