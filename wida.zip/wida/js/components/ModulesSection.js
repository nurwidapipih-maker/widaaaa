/**
 * Komponen ModulesSection
 * Menampilkan grid 6 kartu modul budidaya perikanan dengan status buka bertahap (sequential unlock).
 * (Dileburkan dari ombak_belajar_fungsional.html)
 */
import { store } from '../state/store.js';
import { icons } from '../utils/icons.js';

export function renderModulesSection(mountEl) {
  function renderContent(state) {
    const modules = state.modules;

    mountEl.innerHTML = `
      <section class="modules" id="modul">
        <div class="wrap">
          <div class="section-head">
            <span class="section-tag">Peta Materi</span>
            <h2>6 modul budidaya perikanan</h2>
            <p>Klik modul yang terbuka untuk membaca materi dan mengerjakan kuisnya — modul berikutnya terbuka setelah kuis modul sebelumnya kamu selesaikan.</p>
          </div>

          <div class="module-grid" id="module-cards-container">
            ${modules.map((m) => {
              const status = store.getModuleStatus(m.id);
              const isLocked = status === 'terkunci';
              const isDone = status === 'selesai';

              let statusLabel = 'Terbuka';
              if (isDone) statusLabel = 'Selesai';
              else if (isLocked) statusLabel = 'Terkunci';

              let metaHint = 'Klik untuk membuka';
              if (isDone) metaHint = 'Sudah dituntaskan';
              else if (isLocked) metaHint = 'Selesaikan modul sebelumnya';

              return `
                <div class="mcard ${isLocked ? 'locked' : ''}" data-id="${m.id}" title="${isLocked ? 'Selesaikan modul sebelumnya untuk membuka' : 'Klik untuk belajar'}">
                  <div class="mcard-top" style="background: ${m.gradient};">
                    <span class="seq">${m.seq}</span>
                    <span class="status ${status}">
                      ${isDone ? `${icons.check(11, 3)} Selesai` : (isLocked ? `${icons.lock(11)} Terkunci` : statusLabel)}
                    </span>
                  </div>
                  <div class="mcard-body">
                    <h3>${m.title}</h3>
                    <p>${m.summary || m.description}</p>
                    <div class="mcard-meta">
                      <span class="duration" style="font-size: 0.76rem; color: ${isLocked ? 'var(--mist)' : 'var(--teal)'}; font-weight: 600;">
                        ${metaHint}
                      </span>
                      <span class="xp-tag">+${m.xp} XP</span>
                    </div>
                  </div>
                </div>
              `;
            }).join('')}
          </div>
        </div>
      </section>
    `;

    // Pasang click listener pada tiap kartu modul
    mountEl.querySelectorAll('.mcard').forEach((card) => {
      card.addEventListener('click', () => {
        const id = parseInt(card.getAttribute('data-id'), 10);
        const status = store.getModuleStatus(id);

        if (status === 'terkunci') {
          card.style.transform = 'scale(0.98)';
          setTimeout(() => { card.style.transform = ''; }, 150);
          return;
        }

        // Buka modal materi
        store.setActiveModule(id);
      });
    });
  }

  // Render awal
  renderContent(store.getState());

  // Reaktif terhadap perubahan status modul / progres siswa
  store.subscribe((newState) => {
    renderContent(newState);
  });
}
