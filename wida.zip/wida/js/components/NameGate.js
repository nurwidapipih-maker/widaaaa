/**
 * Komponen NameGate (Sesi Siswa / Onboarding)
 * Meminta nama dan kelas siswa saat pertama kali membuka web.
 * (Dileburkan dari ombak_belajar_fungsional.html)
 */
import { store } from '../state/store.js';
import { icons } from '../utils/icons.js';

export function renderNameGate(mountEl) {
  function render(state) {
    if (!state.isGateOpen) {
      mountEl.innerHTML = '';
      return;
    }

    mountEl.innerHTML = `
      <div class="modal-overlay open" id="gate-overlay" style="z-index: 2000;">
        <div class="modal-dialog" style="max-width: 440px; border-radius: 24px; padding: 0; overflow: hidden;">
          <div class="modal-header" style="background: linear-gradient(135deg, var(--teal), #0E4C6B); padding: 26px 28px;">
            <div>
              <div style="font-size: 0.8rem; color: #BFE3E0; font-weight: 700; letter-spacing: 0.06em; text-transform: uppercase; margin-bottom: 4px; display: flex; align-items: center; gap: 6px;">
                ${icons.fish(16)}
                <span>Selamat Datang di Ombak Belajar</span>
              </div>
              <h3 style="color: white; font-size: 1.4rem; margin: 0;">Mulai Sesi Belajarmu</h3>
            </div>
          </div>

          <div class="modal-body" style="padding: 28px;">
            <p style="color: var(--mist); font-size: 0.92rem; line-height: 1.6; margin-bottom: 20px;">
              Isi namamu untuk mulai belajar. Progres modul, lencana, dan perolehan XP akan tersimpan secara otomatis setiap kamu kembali.
            </p>

            <form id="gate-form">
              <div class="form-group" style="margin-bottom: 16px;">
                <label style="font-size: 0.84rem; font-weight: 600; color: var(--deep); display: block; margin-bottom: 6px;">Nama Lengkap Siswa</label>
                <input type="text" id="gate-input-name" class="form-control" placeholder="Contoh: Rian Pratama" value="${state.student.name || ''}" required autofocus style="width: 100%; padding: 12px 14px; border: 1.5px solid #D5E0DD; border-radius: 10px; font-family: inherit; font-size: 0.95rem;">
              </div>

              <div class="form-group" style="margin-bottom: 24px;">
                <label style="font-size: 0.84rem; font-weight: 600; color: var(--deep); display: block; margin-bottom: 6px;">Kelas / Jurusan</label>
                <input type="text" id="gate-input-class" class="form-control" placeholder="Contoh: XI BAP 1" value="${state.student.class || ''}" style="width: 100%; padding: 12px 14px; border: 1.5px solid #D5E0DD; border-radius: 10px; font-family: inherit; font-size: 0.95rem;">
              </div>

              <button type="submit" class="btn-primary" style="width: 100%; padding: 14px; justify-content: center; font-size: 1rem;">
                Mulai Belajar →
              </button>

              ${state.student.name ? `
                <div style="text-align: center; margin-top: 14px;">
                  <button type="button" id="btn-cancel-gate" style="background: none; border: none; color: var(--mist); font-size: 0.85rem; cursor: pointer;">
                    Batal & Tetap Pakai Profil Ini
                  </button>
                </div>
              ` : ''}
            </form>
          </div>
        </div>
      </div>
    `;

    const form = mountEl.querySelector('#gate-form');
    form?.addEventListener('submit', async (e) => {
      e.preventDefault();
      const name = mountEl.querySelector('#gate-input-name').value.trim();
      const klass = mountEl.querySelector('#gate-input-class').value.trim();
      if (!name) return;

      await store.startStudentSession(name, klass);
    });

    mountEl.querySelector('#btn-cancel-gate')?.addEventListener('click', () => {
      store.closeGate();
    });
  }

  render(store.getState());

  store.subscribe((newState) => {
    render(newState);
  });
}
