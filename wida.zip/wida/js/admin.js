/**
 * Controller Panel Admin CMS Ombak Belajar
 * Mengelola interaksi CRUD 5 tab: Modul, Kuis, Papan Peringkat, Konten Beranda, Profil Siswa.
 * Menggunakan ikon SVG vektor tanpa emoji.
 */
import { store } from './state/store.js';
import { icons } from './utils/icons.js';

document.addEventListener('DOMContentLoaded', () => {
  // Inisialisasi Tab Navigation
  initTabs();

  // Inisialisasi masing-masing tab
  renderModulesTab();
  renderQuizzesTab();
  renderLeaderboardTab();
  initSiteContentTab();
  initProfileTab();

  // Inisialisasi Modal Editors & Aksi Global
  initModuleModal();
  initQuizModal();
  initStudentModal();
  initResetAllButton();

  // Reaktif terhadap perubahan store
  store.subscribe(() => {
    renderModulesTab();
    renderQuizzesTab();
    renderLeaderboardTab();
  });
});

// Toast Notifikasi
function showToast(message, iconSvg = icons.check(16, 2.5)) {
  const toast = document.getElementById('admin-toast');
  const text = document.getElementById('toast-text');
  const iconEl = document.getElementById('toast-icon');

  if (toast && text) {
    text.textContent = message;
    if (iconEl) iconEl.innerHTML = iconSvg;
    toast.classList.add('show');
    setTimeout(() => {
      toast.classList.remove('show');
    }, 3000);
  }
}

// 1. Tab Switching
function initTabs() {
  const tabBtns = document.querySelectorAll('.admin-tab-btn');
  const panes = document.querySelectorAll('.tab-pane');

  tabBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      const targetTab = btn.getAttribute('data-tab');

      tabBtns.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');

      panes.forEach(p => {
        if (p.id === `pane-${targetTab}`) {
          p.classList.add('active');
        } else {
          p.classList.remove('active');
        }
      });
    });
  });
}

// 2. TAB MODUL PEMBELAJARAN
function renderModulesTab() {
  const state = store.getState();
  const modules = state.modules;

  // Render Stats Grid
  const statsContainer = document.getElementById('modules-stats-grid');
  const countBadge = document.getElementById('modules-count-badge');
  if (countBadge) countBadge.textContent = modules.length;

  if (statsContainer) {
    const totalSesi = modules.reduce((sum, m) => sum + (Number(m.sessions) || 0), 0);
    const totalXP = modules.reduce((sum, m) => sum + (Number(m.xp) || 0), 0);
    const selesaiCount = modules.filter(m => m.status === 'selesai').length;

    statsContainer.innerHTML = `
      <div class="admin-stat-card">
        <div class="admin-stat-icon">${icons.book(20)}</div>
        <div class="admin-stat-info">
          <strong>${modules.length}</strong>
          <span>Total Modul</span>
        </div>
      </div>
      <div class="admin-stat-card">
        <div class="admin-stat-icon" style="background:#E7F8EF; color:#2AA96B;">${icons.check(20, 2.5)}</div>
        <div class="admin-stat-info">
          <strong>${selesaiCount}</strong>
          <span>Modul Selesai</span>
        </div>
      </div>
      <div class="admin-stat-card">
        <div class="admin-stat-icon" style="background:#FFF4E5; color:#B4590F;">${icons.clock(20)}</div>
        <div class="admin-stat-info">
          <strong>${totalSesi}</strong>
          <span>Total Sesi Mikro</span>
        </div>
      </div>
      <div class="admin-stat-card">
        <div class="admin-stat-icon" style="background:#FFF1EF; color:#FF6F59;">${icons.star(20)}</div>
        <div class="admin-stat-info">
          <strong>${totalXP}</strong>
          <span>Total XP Kurikulum</span>
        </div>
      </div>
    `;
  }

  // Render Table
  const tableBody = document.getElementById('modules-table-body');
  if (!tableBody) return;

  tableBody.innerHTML = modules.map(m => `
    <tr>
      <td><strong style="font-family: var(--font-serif); font-size: 1rem;">${m.seq}</strong></td>
      <td>
        <div class="mod-title-col">
          <div class="mod-color-tag" style="background: ${m.gradient};"></div>
          <div class="mod-title-text">
            <strong>${m.title}</strong>
            <small>${m.description}</small>
          </div>
        </div>
      </td>
      <td>
        <span style="display:inline-flex; align-items:center; gap:4px;">
          ${icons.clock(13)}
          <span>${m.sessions} sesi (${m.duration})</span>
        </span>
      </td>
      <td>
        <span style="color: var(--gold-text); font-weight: 700; display:inline-flex; align-items:center; gap:4px;">
          ${icons.star(12)}
          <span>+${m.xp} XP</span>
        </span>
      </td>
      <td><span class="status-pill ${m.status}">${m.status}</span></td>
      <td style="text-align: right;">
        <div class="action-btns" style="justify-content: flex-end;">
          <button class="btn-action-edit btn-edit-module" data-id="${m.id}" style="display:inline-flex; align-items:center; gap:4px;">
            ${icons.edit(13)}
            <span>Edit</span>
          </button>
          <button class="btn-action-delete btn-del-module" data-id="${m.id}" title="Hapus Modul">
            ${icons.trash(14)}
          </button>
        </div>
      </td>
    </tr>
  `).join('');

  // Event Listeners Edit & Delete
  tableBody.querySelectorAll('.btn-edit-module').forEach(btn => {
    btn.addEventListener('click', () => {
      const id = parseInt(btn.getAttribute('data-id'), 10);
      openModuleEditor(id);
    });
  });

  tableBody.querySelectorAll('.btn-del-module').forEach(btn => {
    btn.addEventListener('click', () => {
      const id = parseInt(btn.getAttribute('data-id'), 10);
      const mod = store.getState().modules.find(m => m.id === id);
      if (confirm(`Yakin ingin menghapus modul "${mod?.title}"?`)) {
        store.deleteModule(id);
        showToast('Modul berhasil dihapus', icons.trash(16));
      }
    });
  });
}

let currentModuleQuestions = [];

function renderModuleQuestionsList() {
  const container = document.getElementById('mod-questions-list');
  const countBadge = document.getElementById('mod-questions-count');
  if (countBadge) countBadge.textContent = currentModuleQuestions.length;
  if (!container) return;

  container.innerHTML = currentModuleQuestions.map((qItem, qi) => `
    <div class="mod-question-card" style="background: #F8FAF9; border: 1px solid #DCE6E3; border-radius: 12px; padding: 16px;">
      <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px;">
        <strong style="color: var(--deep); font-size: 0.92rem;">Soal Evaluasi ${qi + 1}</strong>
        ${currentModuleQuestions.length > 1 ? `
          <button type="button" class="btn-del-mod-q" data-qi="${qi}" style="background: none; border: none; color: var(--coral); cursor: pointer; display: flex; align-items: center; gap: 4px; font-size: 0.8rem;">
            ${icons.trash(14)}
            <span>Hapus Soal</span>
          </button>
        ` : ''}
      </div>

      <div class="form-group" style="margin-bottom: 12px;">
        <label style="font-size: 0.82rem; font-weight: 600; color: var(--deep);">Pertanyaan Soal ${qi + 1}</label>
        <input type="text" class="form-control mod-q-text" data-qi="${qi}" value="${qItem.q || ''}" placeholder="Tuliskan pertanyaan uji pemahaman...">
      </div>

      <label style="font-size: 0.8rem; font-weight: 600; color: var(--deep); display: block; margin-bottom: 6px;">
        Pilihan Jawaban & Kunci Jawaban Benar (Pilih Radio):
      </label>

      <div style="display: flex; flex-direction: column; gap: 8px;">
        ${[0, 1, 2].map(oi => {
          const optVal = qItem.options && qItem.options[oi] ? qItem.options[oi] : '';
          const isCorrect = qItem.correct === oi;
          return `
            <div class="quiz-option-row">
              <label class="quiz-radio-label">
                <input type="radio" name="mod_correct_${qi}" value="${oi}" data-qi="${qi}" ${isCorrect ? 'checked' : ''}>
                <span>Opsi ${String.fromCharCode(65 + oi)}:</span>
              </label>
              <input type="text" class="form-control mod-opt-text" data-qi="${qi}" data-oi="${oi}" value="${optVal}" placeholder="Pilihan ${String.fromCharCode(65 + oi)}...">
            </div>
          `;
        }).join('')}
      </div>
    </div>
  `).join('');

  // Delete Question listener
  container.querySelectorAll('.btn-del-mod-q').forEach(btn => {
    btn.addEventListener('click', () => {
      const qi = parseInt(btn.getAttribute('data-qi'), 10);
      currentModuleQuestions.splice(qi, 1);
      renderModuleQuestionsList();
    });
  });

  // Track text changes
  container.querySelectorAll('.mod-q-text').forEach(input => {
    input.addEventListener('input', () => {
      const qi = parseInt(input.getAttribute('data-qi'), 10);
      if (currentModuleQuestions[qi]) currentModuleQuestions[qi].q = input.value;
    });
  });

  container.querySelectorAll('.mod-opt-text').forEach(input => {
    input.addEventListener('input', () => {
      const qi = parseInt(input.getAttribute('data-qi'), 10);
      const oi = parseInt(input.getAttribute('data-oi'), 10);
      if (currentModuleQuestions[qi]) {
        if (!currentModuleQuestions[qi].options) currentModuleQuestions[qi].options = ['', '', ''];
        currentModuleQuestions[qi].options[oi] = input.value;
      }
    });
  });

  container.querySelectorAll('input[type="radio"]').forEach(radio => {
    radio.addEventListener('change', () => {
      const qi = parseInt(radio.getAttribute('data-qi'), 10);
      const oi = parseInt(radio.value, 10);
      if (currentModuleQuestions[qi]) currentModuleQuestions[qi].correct = oi;
    });
  });
}

// Editor Modal Modul
function initModuleModal() {
  const overlay = document.getElementById('module-editor-overlay');
  const closeBtn = document.getElementById('btn-close-module-modal');
  const cancelBtn = document.getElementById('btn-cancel-module');
  const saveBtn = document.getElementById('btn-save-module');
  const addBtn = document.getElementById('btn-add-module');
  const addQBtn = document.getElementById('btn-add-mod-q');

  function close() {
    overlay.classList.remove('open');
  }

  closeBtn?.addEventListener('click', close);
  cancelBtn?.addEventListener('click', close);
  overlay?.addEventListener('click', (e) => {
    if (e.target === overlay) close();
  });

  addBtn?.addEventListener('click', () => {
    openModuleEditor(null);
  });

  addQBtn?.addEventListener('click', () => {
    currentModuleQuestions.push({
      q: 'Pertanyaan baru?',
      options: ['Opsi A', 'Opsi B', 'Opsi C'],
      correct: 0
    });
    renderModuleQuestionsList();
  });

  saveBtn?.addEventListener('click', () => {
    const idInput = document.getElementById('edit-module-id').value;
    const isNew = !idInput;

    const pointsText = document.getElementById('edit-mod-materi-points').value;
    const keyPoints = pointsText.split('\n').map(p => p.trim()).filter(Boolean);

    const existingMod = idInput ? store.getState().modules.find(m => m.id === parseInt(idInput, 10)) : null;
    const contentText = document.getElementById('edit-mod-materi-intro').value;
    const contentParagraphs = contentText.split('\n\n').map(p => p.trim()).filter(Boolean);

    // Pastikan pertanyaan valid
    const finalQuestions = currentModuleQuestions.length > 0 ? currentModuleQuestions : [
      {
        q: 'Pertanyaan evaluasi pemahaman?',
        options: ['Pilihan A', 'Pilihan B', 'Pilihan C'],
        correct: 0
      }
    ];

    const moduleData = {
      seq: document.getElementById('edit-mod-seq').value || '01',
      title: document.getElementById('edit-mod-title').value || 'Modul Baru',
      summary: document.getElementById('edit-mod-desc').value || '',
      description: document.getElementById('edit-mod-desc').value || '',
      sessions: parseInt(document.getElementById('edit-mod-sessions').value, 10) || 4,
      duration: document.getElementById('edit-mod-duration').value || '30 menit',
      xp: parseInt(document.getElementById('edit-mod-xp').value, 10) || 60,
      status: document.getElementById('edit-mod-status').value || 'terkunci',
      gradient: document.getElementById('edit-mod-gradient').value,
      content: contentParagraphs.length > 0 ? contentParagraphs : (existingMod?.content || ['Materi pembelajaran budidaya.']),
      questions: finalQuestions,
      materi: {
        intro: contentParagraphs[0] || '',
        keyPoints: keyPoints.length > 0 ? keyPoints : ['Poin materi utama'],
        quiz: {
          question: finalQuestions[0].q,
          options: finalQuestions[0].options.map((opt, i) => ({ text: opt, isCorrect: i === finalQuestions[0].correct })),
          explanation: 'Pelajari kembali materi untuk menjawab dengan tepat.'
        }
      }
    };

    if (isNew) {
      store.addModule(moduleData);
      showToast('Modul baru berhasil ditambahkan!', icons.check(16));
    } else {
      store.updateModule(parseInt(idInput, 10), moduleData);
      showToast('Perubahan modul berhasil disimpan!', icons.check(16));
    }

    close();
  });
}

function openModuleEditor(id) {
  const overlay = document.getElementById('module-editor-overlay');
  const title = document.getElementById('modal-editor-title');
  const idInput = document.getElementById('edit-module-id');

  if (id === null) {
    title.textContent = 'Tambah Modul Baru';
    idInput.value = '';
    const nextSeq = String(store.getState().modules.length + 1).padStart(2, '0');
    document.getElementById('edit-mod-seq').value = nextSeq;
    document.getElementById('edit-mod-title').value = '';
    document.getElementById('edit-mod-desc').value = '';
    document.getElementById('edit-mod-sessions').value = 4;
    document.getElementById('edit-mod-duration').value = '30 menit';
    document.getElementById('edit-mod-xp').value = 70;
    document.getElementById('edit-mod-status').value = 'terkunci';
    document.getElementById('edit-mod-gradient').value = 'linear-gradient(135deg, #1C8C8C, #0E4C6B)';
    document.getElementById('edit-mod-materi-intro').value = '';
    document.getElementById('edit-mod-materi-points').value = '';
    
    currentModuleQuestions = [
      {
        q: 'Pertanyaan evaluasi modul?',
        options: ['Opsi A', 'Opsi B', 'Opsi C'],
        correct: 0
      }
    ];
    renderModuleQuestionsList();
  } else {
    const mod = store.getState().modules.find(m => m.id === id);
    if (!mod) return;

    title.textContent = `Edit Modul ${mod.seq}: ${mod.title}`;
    idInput.value = mod.id;
    document.getElementById('edit-mod-seq').value = mod.seq;
    document.getElementById('edit-mod-title').value = mod.title;
    document.getElementById('edit-mod-desc').value = mod.description || mod.summary || '';
    document.getElementById('edit-mod-sessions').value = mod.sessions;
    document.getElementById('edit-mod-duration').value = mod.duration;
    document.getElementById('edit-mod-xp').value = mod.xp;
    document.getElementById('edit-mod-status').value = mod.status;
    document.getElementById('edit-mod-gradient').value = mod.gradient || 'linear-gradient(135deg, #1C8C8C, #0E4C6B)';
    
    const introText = mod.content ? mod.content.join('\n\n') : (mod.materi?.intro || '');
    document.getElementById('edit-mod-materi-intro').value = introText;
    document.getElementById('edit-mod-materi-points').value = (mod.materi?.keyPoints || []).join('\n');
    
    // Ambil seluruh soal evaluasi
    if (mod.questions && Array.isArray(mod.questions) && mod.questions.length > 0) {
      currentModuleQuestions = JSON.parse(JSON.stringify(mod.questions));
    } else if (mod.materi?.quiz) {
      const q = mod.materi.quiz;
      const cIdx = q.options.findIndex(o => o.isCorrect);
      currentModuleQuestions = [{
        q: q.question,
        options: q.options.map(o => o.text),
        correct: cIdx !== -1 ? cIdx : 0
      }];
    } else {
      currentModuleQuestions = [
        { q: 'Pertanyaan evaluasi?', options: ['Opsi A', 'Opsi B', 'Opsi C'], correct: 0 }
      ];
    }
    renderModuleQuestionsList();
  }

  overlay.classList.add('open');
}

// 3. TAB BANK KUIS INTERAKTIF
function renderQuizzesTab() {
  const quizzes = store.getState().quizzes;
  const tableBody = document.getElementById('quizzes-table-body');
  if (!tableBody) return;

  tableBody.innerHTML = quizzes.map((q, idx) => {
    const correctOpt = q.options.find(o => o.isCorrect)?.text || '-';

    return `
      <tr>
        <td><strong>#${idx + 1}</strong></td>
        <td><span class="status-pill berjalan">${q.tag}</span></td>
        <td><strong style="color: var(--deep);">${q.question}</strong></td>
        <td>
          <span style="color: var(--success); font-weight: 600; display:inline-flex; align-items:center; gap:4px;">
            ${icons.check(13, 2.5)}
            <span>${correctOpt}</span>
          </span>
        </td>
        <td>
          <span style="color: var(--gold-text); font-weight: 700; display:inline-flex; align-items:center; gap:4px;">
            ${icons.star(12)}
            <span>+${q.xpReward} XP</span>
          </span>
        </td>
        <td style="text-align: right;">
          <div class="action-btns" style="justify-content: flex-end;">
            <button class="btn-action-edit btn-edit-quiz" data-id="${q.id}" style="display:inline-flex; align-items:center; gap:4px;">
              ${icons.edit(13)}
              <span>Edit</span>
            </button>
            <button class="btn-action-delete btn-del-quiz" data-id="${q.id}" title="Hapus Soal">
              ${icons.trash(14)}
            </button>
          </div>
        </td>
      </tr>
    `;
  }).join('');

  tableBody.querySelectorAll('.btn-edit-quiz').forEach(btn => {
    btn.addEventListener('click', () => {
      const id = parseInt(btn.getAttribute('data-id'), 10);
      openQuizEditor(id);
    });
  });

  tableBody.querySelectorAll('.btn-del-quiz').forEach(btn => {
    btn.addEventListener('click', () => {
      const id = parseInt(btn.getAttribute('data-id'), 10);
      if (confirm('Yakin ingin menghapus pertanyaan kuis ini?')) {
        store.deleteQuiz(id);
        showToast('Soal kuis berhasil dihapus', icons.trash(16));
      }
    });
  });
}

function initQuizModal() {
  const overlay = document.getElementById('quiz-editor-overlay');
  const closeBtn = document.getElementById('btn-close-quiz-modal');
  const cancelBtn = document.getElementById('btn-cancel-quiz');
  const saveBtn = document.getElementById('btn-save-quiz');
  const addBtn = document.getElementById('btn-add-quiz');

  function close() {
    overlay.classList.remove('open');
  }

  closeBtn?.addEventListener('click', close);
  cancelBtn?.addEventListener('click', close);
  overlay?.addEventListener('click', (e) => {
    if (e.target === overlay) close();
  });

  addBtn?.addEventListener('click', () => {
    openQuizEditor(null);
  });

  saveBtn?.addEventListener('click', () => {
    const idInput = document.getElementById('edit-quiz-id').value;
    const isNew = !idInput;

    const radioVal = document.querySelector('input[name="quiz_correct_opt"]:checked')?.value || '0';
    const correctIndex = parseInt(radioVal, 10);

    const quizData = {
      tag: document.getElementById('edit-quiz-tag').value || 'SESI PRAKTIK',
      question: document.getElementById('edit-quiz-q').value || 'Pertanyaan?',
      xpReward: parseInt(document.getElementById('edit-quiz-xp').value, 10) || 10,
      options: [
        { text: document.getElementById('edit-quiz-opt-0').value || 'Opsi 1', isCorrect: correctIndex === 0 },
        { text: document.getElementById('edit-quiz-opt-1').value || 'Opsi 2', isCorrect: correctIndex === 1 },
        { text: document.getElementById('edit-quiz-opt-2').value || 'Opsi 3', isCorrect: correctIndex === 2 }
      ],
      feedbackCorrect: document.getElementById('edit-quiz-fb-correct').value || 'Betul!',
      feedbackWrong: document.getElementById('edit-quiz-fb-wrong').value || 'Belum tepat.'
    };

    if (isNew) {
      store.addQuiz(quizData);
      showToast('Soal kuis baru berhasil ditambahkan!', icons.check(16));
    } else {
      store.updateQuiz(parseInt(idInput, 10), quizData);
      showToast('Soal kuis berhasil diperbarui!', icons.check(16));
    }

    close();
  });
}

function openQuizEditor(id) {
  const overlay = document.getElementById('quiz-editor-overlay');
  const title = document.getElementById('quiz-modal-title');
  const idInput = document.getElementById('edit-quiz-id');

  if (id === null) {
    title.textContent = 'Tambah Soal Kuis Beranda';
    idInput.value = '';
    document.getElementById('edit-quiz-tag').value = 'SESI UMUM · BUDIDAYA IKAN';
    document.getElementById('edit-quiz-xp').value = 10;
    document.getElementById('edit-quiz-q').value = '';
    document.getElementById('edit-quiz-opt-0').value = '';
    document.getElementById('edit-quiz-opt-1').value = '';
    document.getElementById('edit-quiz-opt-2').value = '';
    document.getElementById('q-radio-0').checked = true;
    document.getElementById('edit-quiz-fb-correct').value = 'Betul sekali!';
    document.getElementById('edit-quiz-fb-wrong').value = 'Belum tepat, coba pelajari kembali materinya.';
  } else {
    const q = store.getState().quizzes.find(item => item.id === id);
    if (!q) return;

    title.textContent = 'Edit Soal Kuis Beranda';
    idInput.value = q.id;
    document.getElementById('edit-quiz-tag').value = q.tag;
    document.getElementById('edit-quiz-xp').value = q.xpReward;
    document.getElementById('edit-quiz-q').value = q.question;
    
    if (q.options && q.options.length >= 3) {
      document.getElementById('edit-quiz-opt-0').value = q.options[0].text;
      document.getElementById('edit-quiz-opt-1').value = q.options[1].text;
      document.getElementById('edit-quiz-opt-2').value = q.options[2].text;

      const cIdx = q.options.findIndex(o => o.isCorrect);
      if (cIdx !== -1) {
        document.getElementById(`q-radio-${cIdx}`).checked = true;
      }
    }

    document.getElementById('edit-quiz-fb-correct').value = q.feedbackCorrect;
    document.getElementById('edit-quiz-fb-wrong').value = q.feedbackWrong;
  }

  overlay.classList.add('open');
}

// 4. TAB PAPAN PERINGKAT
function renderLeaderboardTab() {
  const leaderboard = store.getState().leaderboard;
  const tableBody = document.getElementById('leaderboard-table-body');
  if (!tableBody) return;

  tableBody.innerHTML = leaderboard.map(l => {
    let rankBadge = `${l.rank}`;
    if (l.rank <= 3) {
      rankBadge = `<span style="display:inline-flex; align-items:center; gap:3px;">${icons.medal(l.rank, 15)} <span>${l.rank}</span></span>`;
    }

    return `
      <tr>
        <td><strong>${rankBadge}</strong></td>
        <td>
          <strong>${l.name}</strong>
          ${l.isCurrent ? '<span class="status-pill selesai" style="margin-left:6px; font-size:0.68rem;">Kamu</span>' : ''}
        </td>
        <td>${l.class}</td>
        <td>${l.completedModules} / 6 modul</td>
        <td>
          <strong style="color: var(--gold-text); display:inline-flex; align-items:center; gap:4px;">
            ${icons.star(12)}
            <span>${l.xp} XP</span>
          </strong>
        </td>
        <td style="text-align: right;">
          <div class="action-btns" style="justify-content: flex-end;">
            <button class="btn-action-edit btn-edit-student" data-rank="${l.rank}" style="display:inline-flex; align-items:center; gap:4px;">
              ${icons.edit(13)}
              <span>Edit</span>
            </button>
            <button class="btn-action-delete btn-del-student" data-rank="${l.rank}" title="Hapus Siswa">
              ${icons.trash(14)}
            </button>
          </div>
        </td>
      </tr>
    `;
  }).join('');

  tableBody.querySelectorAll('.btn-edit-student').forEach(btn => {
    btn.addEventListener('click', () => {
      const rank = parseInt(btn.getAttribute('data-rank'), 10);
      openStudentEditor(rank);
    });
  });

  tableBody.querySelectorAll('.btn-del-student').forEach(btn => {
    btn.addEventListener('click', () => {
      const rank = parseInt(btn.getAttribute('data-rank'), 10);
      if (confirm('Yakin ingin menghapus siswa ini dari papan peringkat?')) {
        store.deleteLeaderboardStudent(rank);
        showToast('Siswa berhasil dihapus dari peringkat', icons.trash(16));
      }
    });
  });
}

function initStudentModal() {
  const overlay = document.getElementById('student-editor-overlay');
  const closeBtn = document.getElementById('btn-close-student-modal');
  const cancelBtn = document.getElementById('btn-cancel-student');
  const saveBtn = document.getElementById('btn-save-student');
  const addBtn = document.getElementById('btn-add-student');

  function close() {
    overlay.classList.remove('open');
  }

  closeBtn?.addEventListener('click', close);
  cancelBtn?.addEventListener('click', close);
  overlay?.addEventListener('click', (e) => {
    if (e.target === overlay) close();
  });

  addBtn?.addEventListener('click', () => {
    openStudentEditor(null);
  });

  saveBtn?.addEventListener('click', () => {
    const rankInput = document.getElementById('edit-student-rank').value;
    const isNew = !rankInput;

    const studentData = {
      name: document.getElementById('edit-student-name').value || 'Nama Siswa',
      class: document.getElementById('edit-student-class').value || 'XI BAP 1',
      completedModules: parseInt(document.getElementById('edit-student-completed').value, 10) || 0,
      xp: parseInt(document.getElementById('edit-student-xp').value, 10) || 0
    };

    if (isNew) {
      store.addLeaderboardStudent(studentData);
      showToast('Siswa baru berhasil ditambahkan ke peringkat!', icons.check(16));
    } else {
      store.updateLeaderboardItem(parseInt(rankInput, 10), studentData);
      showToast('Data siswa berhasil diperbarui!', icons.check(16));
    }

    close();
  });
}

function openStudentEditor(rank) {
  const overlay = document.getElementById('student-editor-overlay');
  const title = document.getElementById('student-modal-title');
  const rankInput = document.getElementById('edit-student-rank');

  if (rank === null) {
    title.textContent = 'Tambah Siswa ke Peringkat';
    rankInput.value = '';
    document.getElementById('edit-student-name').value = '';
    document.getElementById('edit-student-class').value = 'XI BAP 1';
    document.getElementById('edit-student-completed').value = 1;
    document.getElementById('edit-student-xp').value = 100;
  } else {
    const item = store.getState().leaderboard.find(l => l.rank === rank);
    if (!item) return;

    title.textContent = `Edit Siswa Peringkat ${item.rank}`;
    rankInput.value = item.rank;
    document.getElementById('edit-student-name').value = item.name;
    document.getElementById('edit-student-class').value = item.class;
    document.getElementById('edit-student-completed').value = item.completedModules;
    document.getElementById('edit-student-xp').value = item.xp;
  }

  overlay.classList.add('open');
}

// 5. TAB TEKS & KONTEN BERANDA
function initSiteContentTab() {
  const site = store.getState().siteContent;

  // 1. Hero
  document.getElementById('site-hero-badge').value = site.hero.badge;
  document.getElementById('site-hero-title').value = site.hero.title;
  document.getElementById('site-hero-lead').value = site.hero.lead;
  document.getElementById('site-hero-btn1').value = site.hero.btnPrimary;
  document.getElementById('site-hero-btn2').value = site.hero.btnGhost;

  document.getElementById('btn-save-hero')?.addEventListener('click', () => {
    store.updateSiteContent({
      hero: {
        ...store.getState().siteContent.hero,
        badge: document.getElementById('site-hero-badge').value,
        title: document.getElementById('site-hero-title').value,
        lead: document.getElementById('site-hero-lead').value,
        btnPrimary: document.getElementById('site-hero-btn1').value,
        btnGhost: document.getElementById('site-hero-btn2').value
      }
    });
    showToast('Konten Hero berhasil diperbarui!', icons.check(16));
  });

  // 2. Why Section & Cards
  document.getElementById('site-why-tag').value = site.why.tag;
  document.getElementById('site-why-title').value = site.why.title;
  document.getElementById('site-why-lead').value = site.why.lead;

  const cardsContainer = document.getElementById('why-cards-inputs');
  if (cardsContainer) {
    cardsContainer.innerHTML = site.why.cards.map((c, i) => `
      <div style="background: #F8FAF9; padding: 14px; border-radius: 12px; border: 1px solid #E5EBE9; margin-top: 12px;">
        <strong>Kartu Pilar ${c.num}</strong>
        <div class="form-grid-2" style="margin-top: 8px;">
          <div class="form-group">
            <label>Judul Kartu</label>
            <input type="text" class="form-control" id="why-c-title-${i}" value="${c.title}">
          </div>
          <div class="form-group">
            <label>Deskripsi Kartu</label>
            <textarea class="form-control" id="why-c-desc-${i}" style="min-height: 50px;">${c.desc}</textarea>
          </div>
        </div>
      </div>
    `).join('');
  }

  document.getElementById('btn-save-why')?.addEventListener('click', () => {
    const updatedCards = site.why.cards.map((c, i) => ({
      num: c.num,
      title: document.getElementById(`why-c-title-${i}`).value,
      desc: document.getElementById(`why-c-desc-${i}`).value
    }));

    store.updateSiteContent({
      why: {
        tag: document.getElementById('site-why-tag').value,
        title: document.getElementById('site-why-title').value,
        lead: document.getElementById('site-why-lead').value,
        cards: updatedCards
      }
    });
    showToast('3 Pilar Keunggulan berhasil diperbarui!', icons.check(16));
  });

  // 3. CTA & Footer
  document.getElementById('site-cta-title').value = site.cta.title;
  document.getElementById('site-cta-lead').value = site.cta.lead;
  document.getElementById('site-cta-btn').value = site.cta.btnText;
  document.getElementById('site-footer-brand').value = site.footer.brandText;
  document.getElementById('site-footer-notice').value = site.footer.noticeText;

  document.getElementById('btn-save-cta-footer')?.addEventListener('click', () => {
    store.updateSiteContent({
      cta: {
        title: document.getElementById('site-cta-title').value,
        lead: document.getElementById('site-cta-lead').value,
        btnText: document.getElementById('site-cta-btn').value
      },
      footer: {
        ...store.getState().siteContent.footer,
        brandText: document.getElementById('site-footer-brand').value,
        noticeText: document.getElementById('site-footer-notice').value
      }
    });
    showToast('Teks CTA & Footer berhasil diperbarui!', icons.check(16));
  });
}

// 6. TAB PROFIL SISWA & KONFIGURASI FIREBASE
function initProfileTab() {
  const state = store.getState();
  const student = state.student || state.user || {};
  const levelInfo = store.getCurrentLevel();

  const nameInput = document.getElementById('user-name');
  const classInput = document.getElementById('user-class');
  const levelInput = document.getElementById('user-level');
  const titleInput = document.getElementById('user-title');
  const xpInput = document.getElementById('user-xp');
  const targetInput = document.getElementById('user-target');

  if (nameInput) nameInput.value = student.name || 'Budi Santoso';
  if (classInput) classInput.value = student.class || 'XI BAP 1';
  if (levelInput) levelInput.value = levelInfo.level || 1;
  if (titleInput) titleInput.value = levelInfo.title || 'Nelayan Pemula';
  if (xpInput) xpInput.value = student.xp || 0;
  if (targetInput) targetInput.value = student.weeklyTargetPercent || 50;

  document.getElementById('btn-save-user')?.addEventListener('click', () => {
    store.updateUserProfile({
      name: document.getElementById('user-name').value,
      class: document.getElementById('user-class').value,
      xp: parseInt(document.getElementById('user-xp').value, 10) || 0,
      weeklyTargetPercent: parseInt(document.getElementById('user-target').value, 10) || 50
    });
    showToast('Profil Siswa berhasil diperbarui!', icons.user(16));
  });

  // Bagian Konfigurasi Firebase Cloud Sync
  initFirebaseConfigCard();
}

function initFirebaseConfigCard() {
  const badge = document.getElementById('admin-fb-status-badge');
  const apiKeyInput = document.getElementById('fb-api-key');
  const projectIdInput = document.getElementById('fb-project-id');
  const authDomainInput = document.getElementById('fb-auth-domain');
  const storageBucketInput = document.getElementById('fb-storage-bucket');
  const senderIdInput = document.getElementById('fb-sender-id');
  const appIdInput = document.getElementById('fb-app-id');

  const rawConfig = localStorage.getItem('ombak_firebase_config');
  let config = rawConfig ? JSON.parse(rawConfig) : (typeof window !== 'undefined' && window.FIREBASE_CONFIG ? window.FIREBASE_CONFIG : null);

  function updateBadge() {
    if (badge) {
      if (store.firebaseActive) {
        badge.textContent = 'Mode Firebase Aktif';
        badge.style.background = '#E7F8EF';
        badge.style.color = '#0E663B';
      } else {
        badge.textContent = 'Mode Lokal (Aktif)';
        badge.style.background = '#EAEAEA';
        badge.style.color = '#555';
      }
    }
  }

  if (config) {
    if (apiKeyInput) apiKeyInput.value = config.apiKey || '';
    if (projectIdInput) projectIdInput.value = config.projectId || '';
    if (authDomainInput) authDomainInput.value = config.authDomain || '';
    if (storageBucketInput) storageBucketInput.value = config.storageBucket || '';
    if (senderIdInput) senderIdInput.value = config.messagingSenderId || '';
    if (appIdInput) appIdInput.value = config.appId || '';
  }

  updateBadge();

  document.getElementById('btn-save-firebase')?.addEventListener('click', () => {
    const apiKey = apiKeyInput?.value.trim() || '';
    const projectId = projectIdInput?.value.trim() || '';
    const authDomain = authDomainInput?.value.trim() || '';
    const storageBucket = storageBucketInput?.value.trim() || '';
    const messagingSenderId = senderIdInput?.value.trim() || '';
    const appId = appIdInput?.value.trim() || '';

    if (!apiKey || !projectId) {
      alert('Mohon isi minimal API Key dan Project ID dari Firebase Console.');
      return;
    }

    const newConfig = { apiKey, projectId, authDomain, storageBucket, messagingSenderId, appId };
    const success = store.setFirebaseConfig(newConfig);

    updateBadge();
    if (success) {
      showToast('Mode Firebase berhasil diaktifkan & terhubung!', icons.check(16));
    } else {
      showToast('Firebase tersimpan (akan aktif jika script compat tersedia)', icons.settings(16));
    }
  });

  document.getElementById('btn-clear-firebase')?.addEventListener('click', () => {
    store.clearFirebaseConfig();
    if (apiKeyInput) apiKeyInput.value = '';
    if (projectIdInput) projectIdInput.value = '';
    if (authDomainInput) authDomainInput.value = '';
    if (storageBucketInput) storageBucketInput.value = '';
    if (senderIdInput) senderIdInput.value = '';
    if (appIdInput) appIdInput.value = '';
    updateBadge();
    showToast('Kembali ke Mode Lokal (penyimpanan browser)', icons.refresh(16));
  });
}

// 7. Reset All Data Button
function initResetAllButton() {
  document.getElementById('btn-reset-all')?.addEventListener('click', () => {
    if (confirm('PERINGATAN: Apakah Anda yakin ingin mereset SELURUH data modul, kuis, peringkat, dan teks beranda kembali ke bawaan kurikulum awal?')) {
      store.resetAllToDefault();
      initSiteContentTab();
      initProfileTab();
      showToast('Seluruh data berhasil di-reset ke bawaan kurikulum!', icons.refresh(16));
    }
  });
}
