/**
 * Store - State Management Terpusat Vanilla JS
 * Menggabungkan seluruh fungsionalitas dari ombak_belajar_fungsional.html:
 * - Onboarding/Sesi Siswa (Gate, Auto-login, Switch Student)
 * - Leveling 4 Tingkat (Nelayan Pemula s/d Master Budidaya)
 * - Kuis Multi-Soal per Modul & Evaluasi Passing Grade (>= 60%)
 * - Buka Modul Bertahap (Sequential Unlock)
 * - Dukungan Sinkronisasi Cloud Firebase Firestore (Opsional) & Mode Lokal
 */
import { modulesData } from '../data/modulesData.js';
import { quizData } from '../data/quizData.js';
import { defaultSiteContent } from '../data/siteContentData.js';

const KEY_MODULES = 'ombak_modules_data';
const KEY_QUIZZES = 'ombak_quiz_data';
const KEY_SITE_CONTENT = 'ombak_site_content';
const KEY_CURRENT_ID = 'ombak_current_id';
const PREFIX_STUDENT = 'ombak_student_';
const KEY_REGISTRY = 'ombak_students_registry';

export const LEVELS = [
  { min: 0, label: 'Nelayan Pemula' },
  { min: 100, label: 'Nelayan Muda' },
  { min: 220, label: 'Pembudidaya Andal' },
  { min: 350, label: 'Master Budidaya' }
];

class Store {
  constructor() {
    this.firebaseActive = false;
    this.db = null;
    this.initFirebase();

    this.state = {
      modules: this.loadData(KEY_MODULES, modulesData),
      quizzes: this.loadData(KEY_QUIZZES, quizData),
      leaderboard: [],
      siteContent: this.loadData(KEY_SITE_CONTENT, defaultSiteContent),
      studentId: null,
      student: {
        name: '',
        class: '',
        xp: 0,
        completed: []
      },
      isGateOpen: false,
      activeModuleId: null
    };

    this.listeners = [];
    this.buildLeaderboardFromRegistry();
    this.initStudentSession();
  }

  // Deteksi & Inisialisasi Firebase Firestore jika window.firebase ada dan terkonfigurasi
  initFirebase() {
    try {
      const savedConfig = localStorage.getItem('ombak_firebase_config');
      let config = savedConfig ? JSON.parse(savedConfig) : null;

      if (!config && typeof window !== 'undefined' && window.FIREBASE_CONFIG) {
        config = window.FIREBASE_CONFIG;
      }

      if (config && config.apiKey && config.apiKey !== 'ISI_DENGAN_API_KEY_ANDA' && typeof firebase !== 'undefined') {
        if (!firebase.apps.length) {
          firebase.initializeApp(config);
        }
        this.db = firebase.firestore();
        this.firebaseActive = true;
        console.log('[Ombak Belajar] Mode Firebase Aktif');
      } else {
        this.firebaseActive = false;
        this.db = null;
      }
    } catch (e) {
      console.warn('[Ombak Belajar] Firebase tidak aktif, berjalan dalam Mode Lokal:', e);
      this.firebaseActive = false;
      this.db = null;
    }
  }

  setFirebaseConfig(config) {
    try {
      localStorage.setItem('ombak_firebase_config', JSON.stringify(config));
      this.initFirebase();
      if (this.firebaseActive) {
        this.fetchFirebaseLeaderboard();
      }
      this.notify();
      return this.firebaseActive;
    } catch (e) {
      console.error('Gagal menyimpan config Firebase:', e);
      return false;
    }
  }

  clearFirebaseConfig() {
    localStorage.removeItem('ombak_firebase_config');
    this.firebaseActive = false;
    this.db = null;
    this.notify();
  }

  async fetchFirebaseLeaderboard() {
    if (!this.firebaseActive || !this.db) return null;
    try {
      const snap = await this.db.collection('students').orderBy('xp', 'desc').limit(10).get();
      if (!snap.empty) {
        const rows = snap.docs.map((d, i) => {
          const data = d.data();
          const isCurrent = this.state.studentId && d.id === this.state.studentId;
          return {
            rank: i + 1,
            name: data.name || 'Siswa',
            class: data.class || '-',
            completedModules: (data.completed || []).length,
            xp: data.xp || 0,
            isCurrent
          };
        });
        this.state.leaderboard = rows;
        this.notify();
        return rows;
      }
    } catch (e) {
      console.warn('Gagal memuat leaderboard dari Firestore:', e);
    }
    return null;
  }

  slugify(str) {
    return (str || '').toLowerCase().trim().replace(/[^a-z0-9]+/g, '-');
  }

  // Inisialisasi Sesi Siswa (Auto-login jika ada sesi sebelumnya)
  async initStudentSession() {
    if (this.firebaseActive) {
      await this.fetchFirebaseLeaderboard();
    }

    const currentId = localStorage.getItem(KEY_CURRENT_ID);
    if (currentId) {
      const existing = await this.loadStudentFromStorage(currentId);
      if (existing) {
        this.state.studentId = currentId;
        this.state.student = existing;
        this.state.isGateOpen = false;
        this.notify();
        return;
      }
    }
    // Jika belum login, buka Name Gate
    this.state.isGateOpen = true;
    this.notify();
  }

  async loadStudentFromStorage(id) {
    if (this.firebaseActive && this.db) {
      try {
        const doc = await this.db.collection('students').doc(id).get();
        if (doc.exists) return doc.data();
      } catch (e) {
        console.warn('Gagal memuat siswa dari Firebase:', e);
      }
    }
    const raw = localStorage.getItem(PREFIX_STUDENT + id);
    return raw ? JSON.parse(raw) : null;
  }

  async saveStudentToStorage(id, data) {
    localStorage.setItem(PREFIX_STUDENT + id, JSON.stringify(data));
    localStorage.setItem(KEY_CURRENT_ID, id);

    if (this.firebaseActive && this.db) {
      try {
        await this.db.collection('students').doc(id).set(data, { merge: true });
      } catch (e) {
        console.warn('Gagal menyimpan siswa ke Firebase:', e);
      }
    }
  }

  // Mulai Sesi Siswa Baru / Login
  async startStudentSession(name, klass) {
    const trimmedName = (name || '').trim();
    const trimmedClass = (klass || '').trim();
    if (!trimmedName) return false;

    const id = this.slugify(`${trimmedName}-${trimmedClass}`);
    let existing = await this.loadStudentFromStorage(id);

    if (!existing) {
      existing = {
        name: trimmedName,
        class: trimmedClass,
        xp: 0,
        completed: []
      };
      await this.saveStudentToStorage(id, existing);
    }

    this.state.studentId = id;
    this.state.student = existing;
    this.state.isGateOpen = false;

    // Sinkronkan ke leaderboard lokal
    this.syncCurrentStudentToLeaderboard();

    this.notify();
    return true;
  }

  // Buka Gate untuk Ganti Siswa
  openGate() {
    this.state.isGateOpen = true;
    this.notify();
  }

  closeGate() {
    if (this.state.student.name) {
      this.state.isGateOpen = false;
      this.notify();
    }
  }

  // Hitung Level & Julukan Siswa
  getCurrentLevel() {
    const xp = this.state.student.xp || 0;
    let current = LEVELS[0];
    let levelNum = 1;

    LEVELS.forEach((lvl, idx) => {
      if (xp >= lvl.min) {
        current = lvl;
        levelNum = idx + 1;
      }
    });

    return {
      level: levelNum,
      title: current.label,
      xp
    };
  }

  // Evaluasi Jawaban Kuis Modul
  async submitModuleQuiz(moduleId, answers) {
    const mod = this.state.modules.find(m => m.id === moduleId);
    if (!mod || !mod.questions) return null;

    const total = mod.questions.length;
    let correctCount = 0;

    mod.questions.forEach((q, qi) => {
      const chosen = answers[qi];
      if (chosen === q.correct) {
        correctCount++;
      }
    });

    const passed = correctCount >= Math.ceil(total * 0.6);
    const alreadyCompleted = this.state.student.completed.includes(moduleId);
    let xpAwarded = 0;

    if (passed && !alreadyCompleted) {
      this.state.student.completed.push(moduleId);
      xpAwarded = Number(mod.xp) || 60;
      this.state.student.xp += xpAwarded;

      await this.saveStudentToStorage(this.state.studentId, this.state.student);
      this.syncCurrentStudentToLeaderboard();
      this.notify();
    }

    return {
      passed,
      score: correctCount,
      total,
      xpAwarded,
      alreadyCompleted
    };
  }

  // Cek Status Modul Berdasarkan Progres Siswa
  getModuleStatus(moduleId) {
    const mod = this.state.modules.find(m => m.id === moduleId);
    if (!mod) return 'terkunci';

    const idx = this.state.modules.findIndex(m => m.id === moduleId);
    const isDone = this.state.student.completed.includes(moduleId);

    if (isDone) return 'selesai';

    const prevDone = idx === 0 || this.state.student.completed.includes(this.state.modules[idx - 1].id);
    if (prevDone) return 'berjalan';

    return 'terkunci';
  }

  // Daftarkan siswa ke registry jika belum ada
  registerStudentToRegistry(id) {
    const registry = this.loadData(KEY_REGISTRY, []);
    if (!registry.includes(id)) {
      registry.push(id);
      this.saveData(KEY_REGISTRY, registry);
    }
  }

  // Bangun leaderboard dari semua siswa terdaftar (data real)
  buildLeaderboardFromRegistry() {
    const registry = this.loadData(KEY_REGISTRY, []);
    const rows = [];

    registry.forEach(id => {
      const raw = localStorage.getItem(PREFIX_STUDENT + id);
      if (!raw) return;
      try {
        const data = JSON.parse(raw);
        const isCurrent = this.state.studentId && id === this.state.studentId;
        rows.push({
          id,
          name: data.name || 'Siswa',
          class: data.class || '-',
          completedModules: (data.completed || []).length,
          xp: data.xp || 0,
          isCurrent
        });
      } catch (e) { /* skip corrupt entries */ }
    });

    // Urutkan berdasarkan XP tertinggi
    rows.sort((a, b) => b.xp - a.xp);
    rows.forEach((r, i) => { r.rank = i + 1; });

    this.state.leaderboard = rows;
  }

  syncCurrentStudentToLeaderboard() {
    if (!this.state.student.name || !this.state.studentId) return;
    // Pastikan siswa aktif terdaftar di registry
    this.registerStudentToRegistry(this.state.studentId);
    // Rebuild leaderboard dari semua data siswa real
    this.buildLeaderboardFromRegistry();
  }

  // Tambah XP Umum (misal dari kuis interaktif beranda)
  async addXP(amount) {
    this.state.student.xp += amount;
    if (this.state.studentId) {
      await this.saveStudentToStorage(this.state.studentId, this.state.student);
    }
    this.syncCurrentStudentToLeaderboard();
    this.notify();
  }

  loadData(key, fallback) {
    try {
      const saved = localStorage.getItem(key);
      if (saved) {
        return JSON.parse(saved);
      }
    } catch (e) {
      console.warn(`Gagal memuat ${key} dari localStorage:`, e);
    }
    return JSON.parse(JSON.stringify(fallback));
  }

  saveData(key, value) {
    try {
      localStorage.setItem(key, JSON.stringify(value));
    } catch (e) {
      console.error(`Gagal menyimpan ${key} ke localStorage:`, e);
    }
  }

  subscribe(listener) {
    this.listeners.push(listener);
    return () => {
      this.listeners = this.listeners.filter(l => l !== listener);
    };
  }

  notify() {
    this.listeners.forEach(listener => listener(this.state));
  }

  getState() {
    return {
      ...this.state,
      user: this.state.student
    };
  }

  setActiveModule(moduleId) {
    this.state.activeModuleId = moduleId;
    this.notify();
  }

  // ===== METODE ADMIN CMS =====
  updateSiteContent(newContent) {
    this.state.siteContent = { ...this.state.siteContent, ...newContent };
    this.saveData(KEY_SITE_CONTENT, this.state.siteContent);
    this.notify();
  }

  updateModule(id, updatedData) {
    const idx = this.state.modules.findIndex(m => m.id === id);
    if (idx !== -1) {
      this.state.modules[idx] = { ...this.state.modules[idx], ...updatedData };
      this.saveData(KEY_MODULES, this.state.modules);
      this.notify();
      return true;
    }
    return false;
  }

  addModule(newModule) {
    const maxId = this.state.modules.reduce((max, m) => Math.max(max, m.id || 0), 0);
    const id = maxId + 1;
    const seq = String(id).padStart(2, '0');

    const mod = {
      id,
      seq: newModule.seq || seq,
      title: newModule.title || 'Modul Baru',
      summary: newModule.summary || newModule.description || '',
      description: newModule.description || newModule.summary || '',
      sessions: Number(newModule.sessions) || 4,
      duration: newModule.duration || '30 menit',
      xp: Number(newModule.xp) || 60,
      status: newModule.status || 'terkunci',
      gradient: newModule.gradient || 'linear-gradient(135deg, #1C8C8C, #0E4C6B)',
      content: newModule.content || ['Isi materi pembelajaran.'],
      questions: newModule.questions || [
        {
          q: 'Pertanyaan evaluasi?',
          options: ['Pilihan A', 'Pilihan B', 'Pilihan C'],
          correct: 0
        }
      ]
    };

    this.state.modules.push(mod);
    this.saveData(KEY_MODULES, this.state.modules);
    this.notify();
    return mod;
  }

  deleteModule(id) {
    this.state.modules = this.state.modules.filter(m => m.id !== id);
    this.saveData(KEY_MODULES, this.state.modules);
    this.notify();
  }

  updateQuiz(id, updatedData) {
    const idx = this.state.quizzes.findIndex(q => q.id === id);
    if (idx !== -1) {
      this.state.quizzes[idx] = { ...this.state.quizzes[idx], ...updatedData };
      this.saveData(KEY_QUIZZES, this.state.quizzes);
      this.notify();
      return true;
    }
    return false;
  }

  addQuiz(newQuiz) {
    const maxId = this.state.quizzes.reduce((max, q) => Math.max(max, q.id || 0), 0);
    const id = maxId + 1;
    const quiz = {
      id,
      tag: newQuiz.tag || 'SESI PRAKTIK',
      question: newQuiz.question || 'Pertanyaan baru?',
      options: newQuiz.options || [
        { text: 'Opsi A', isCorrect: true },
        { text: 'Opsi B', isCorrect: false },
        { text: 'Opsi C', isCorrect: false }
      ],
      feedbackCorrect: newQuiz.feedbackCorrect || 'Jawaban Anda benar!',
      feedbackWrong: newQuiz.feedbackWrong || 'Belum tepat. Coba lagi!',
      xpReward: Number(newQuiz.xpReward) || 10
    };
    this.state.quizzes.push(quiz);
    this.saveData(KEY_QUIZZES, this.state.quizzes);
    this.notify();
    return quiz;
  }

  deleteQuiz(id) {
    this.state.quizzes = this.state.quizzes.filter(q => q.id !== id);
    this.saveData(KEY_QUIZZES, this.state.quizzes);
    this.notify();
  }

  updateLeaderboardItem(rank, updatedData) {
    const idx = this.state.leaderboard.findIndex(l => l.rank === rank);
    if (idx !== -1) {
      this.state.leaderboard[idx] = { ...this.state.leaderboard[idx], ...updatedData };
      this.saveData(KEY_LEADERBOARD, this.state.leaderboard);
      this.notify();
      return true;
    }
    return false;
  }

  addLeaderboardStudent(student) {
    const rank = this.state.leaderboard.length + 1;
    const newStudent = {
      rank,
      name: student.name || 'Siswa Baru',
      class: student.class || 'XI BAP 1',
      completedModules: Number(student.completedModules) || 0,
      xp: Number(student.xp) || 0,
      isCurrent: !!student.isCurrent
    };
    this.state.leaderboard.push(newStudent);
    this.saveData(KEY_LEADERBOARD, this.state.leaderboard);
    this.notify();
    return newStudent;
  }

  deleteLeaderboardStudent(rank) {
    this.state.leaderboard = this.state.leaderboard.filter(l => l.rank !== rank);
    this.state.leaderboard.forEach((item, i) => { item.rank = i + 1; });
    this.saveData(KEY_LEADERBOARD, this.state.leaderboard);
    this.notify();
  }

  updateUserProfile(userData) {
    this.state.student = { ...this.state.student, ...userData };
    if (this.state.studentId) {
      this.saveStudentToStorage(this.state.studentId, this.state.student);
    }
    this.syncCurrentStudentToLeaderboard();
    this.notify();
  }

  resetAllToDefault() {
    this.state.modules = JSON.parse(JSON.stringify(modulesData));
    this.state.quizzes = JSON.parse(JSON.stringify(quizData));
    this.state.siteContent = JSON.parse(JSON.stringify(defaultSiteContent));

    // Bersihkan semua data siswa dari registry
    const registry = this.loadData(KEY_REGISTRY, []);
    registry.forEach(id => localStorage.removeItem(PREFIX_STUDENT + id));
    localStorage.removeItem(KEY_REGISTRY);
    localStorage.removeItem(KEY_CURRENT_ID);

    // Reset siswa aktif
    this.state.student = { name: '', class: '', xp: 0, completed: [] };
    this.state.studentId = null;
    this.state.leaderboard = [];
    this.state.isGateOpen = true;

    this.saveData(KEY_MODULES, this.state.modules);
    this.saveData(KEY_QUIZZES, this.state.quizzes);
    this.saveData(KEY_SITE_CONTENT, this.state.siteContent);

    this.notify();
  }
}

export const store = new Store();
