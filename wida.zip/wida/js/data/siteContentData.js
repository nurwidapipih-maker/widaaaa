/**
 * Data Teks & Konten Bawaan Beranda Ombak Belajar
 * (Dapat diedit melalui Panel Admin)
 */
export const defaultSiteContent = {
  hero: {
    badge: 'Budidaya Perairan · Kelas XI',
    title: 'Belajar budidaya ikan, sekencang arus pengetahuanmu sendiri.',
    lead: 'Materi produktif perikanan dikemas jadi sesi-sesi singkat, ada tantangan dan lencana di tiap capaian — biar paham materi tanpa kepala penuh sesak.',
    btnPrimary: 'Lanjutkan Modul →',
    btnGhost: 'Lihat Semua Materi',
    stats: {
      modulesCount: '6',
      modulesLabel: 'Modul praktis',
      sessionsCount: '24',
      sessionsLabel: 'Sesi mikro (±8 menit)',
      badgesCount: '12',
      badgesLabel: 'Lencana capaian'
    }
  },
  why: {
    tag: 'Kenapa Berbeda',
    title: 'Dirancang supaya paham materi, bukan menghafal semalam',
    lead: 'Sesi singkat, capaian yang terasa, dan konten yang langsung dipakai di kolam — bukan tumpukan slide yang bikin jenuh.',
    cards: [
      {
        num: '01',
        title: 'Sesi mikro, bukan maraton',
        desc: 'Tiap topik dipecah jadi sesi 6–10 menit, jadi bisa dicicil sela waktu praktik atau istirahat, tanpa menumpuk di akhir semester.'
      },
      {
        num: '02',
        title: 'Konten dari kolam, bukan teori kosong',
        desc: 'Studi kasus dan simulasi diambil dari praktik nyata budidaya — kualitas air, pembenihan, sampai panen — biar terasa relevan.'
      },
      {
        num: '03',
        title: 'Capaian yang terlihat',
        desc: 'Progress bar, lencana, dan level naik setiap kamu menuntaskan modul — supaya usaha belajarmu terasa nyata, bukan abstrak.'
      }
    ]
  },
  cta: {
    title: 'Modul berikutnya menunggu, tanpa terburu-buru.',
    lead: 'Lanjutkan dari sesi terakhirmu — sistem menyimpan capaian dan progres belajarmu secara otomatis.',
    btnText: 'Lanjutkan Belajar →'
  },
  footer: {
    brandText: 'Ombak Belajar — Media Pembelajaran Budidaya Perairan SMK',
    badgeText: 'Metode R&D Vanilla Architecture',
    noticeText: 'Dibuat untuk keperluan proposal & penelitian pendidikan'
  }
};
