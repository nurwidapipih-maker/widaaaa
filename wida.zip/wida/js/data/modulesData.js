/**
 * Data Modul Pembelajaran Ombak Belajar
 * Kurikulum Lengkap Budidaya Perikanan SMK Kelas XI
 * (Dileburkan dari ombak_belajar_fungsional.html)
 */
export const modulesData = [
  {
    id: 1,
    seq: '01',
    title: 'Pengenalan Budidaya Perairan',
    summary: 'Mengenal jenis wadah budidaya, komoditas unggulan, dan siklus produksinya.',
    description: 'Mengenal jenis wadah budidaya, komoditas unggulan, dan siklus produksinya.',
    sessions: 4,
    duration: '32 menit',
    xp: 60,
    status: 'terbuka',
    gradient: 'linear-gradient(135deg, #1C8C8C, #0E4C6B)',
    content: [
      'Budidaya perairan (akuakultur) adalah kegiatan memelihara dan membesarkan organisme air — seperti ikan, udang, dan rumput laut — dalam wadah dan lingkungan yang dikendalikan, dengan tujuan memperoleh hasil panen yang optimal.',
      'Wadah budidaya yang umum digunakan antara lain kolam tanah, kolam terpal, tambak (air payau), keramba jaring apung (mengapung di danau/waduk), dan akuarium untuk skala kecil/pembenihan.',
      'Komoditas yang umum dibudidayakan di Indonesia antara lain ikan nila dan lele (air tawar), udang vaname (air payau), serta rumput laut (air laut).',
      'Secara umum, siklus produksi budidaya berjalan dalam empat tahap: persiapan wadah, penebaran benih, masa pembesaran, dan panen.'
    ],
    questions: [
      {
        q: 'Wadah budidaya yang mengapung di perairan umum seperti danau atau waduk disebut?',
        options: ['Tambak', 'Keramba jaring apung', 'Akuarium'],
        correct: 1
      },
      {
        q: 'Berikut yang termasuk komoditas budidaya air tawar adalah?',
        options: ['Udang vaname', 'Rumput laut', 'Ikan nila'],
        correct: 2
      },
      {
        q: 'Urutan siklus produksi budidaya yang tepat adalah?',
        options: [
          'Panen – penebaran benih – persiapan wadah – pembesaran',
          'Persiapan wadah – penebaran benih – pembesaran – panen',
          'Pembesaran – panen – persiapan wadah – penebaran benih'
        ],
        correct: 1
      }
    ]
  },
  {
    id: 2,
    seq: '02',
    title: 'Kualitas Air Kolam',
    summary: 'Mengukur pH, suhu, dan oksigen terlarut — dan cara menjaganya tetap stabil.',
    description: 'Mengukur pH, suhu, dan oksigen terlarut — dan cara menjaganya tetap stabil.',
    sessions: 5,
    duration: '38 menit',
    xp: 80,
    status: 'terkunci',
    gradient: 'linear-gradient(135deg, #2AA9A0, #1C8C8C)',
    content: [
      'Kualitas air adalah faktor penentu utama keberhasilan budidaya. Empat parameter yang paling sering dipantau adalah suhu, pH (derajat keasaman), oksigen terlarut (DO — dissolved oxygen), dan kadar amonia.',
      'Untuk sebagian besar ikan air tawar, kisaran ideal umumnya: suhu 25–30°C, pH 6,5–8,5, dan DO di atas 4 mg/L.',
      'Air dengan kualitas buruk dapat menyebabkan ikan stres, mudah terserang penyakit, hingga kematian massal jika dibiarkan terlalu lama.',
      'Cara sederhana menjaga kualitas air antara lain: pergantian air secara berkala, pemberian aerasi (penambah oksigen), dan mengontrol jumlah pakan agar tidak berlebihan (sisa pakan adalah penyebab utama naiknya amonia).'
    ],
    questions: [
      {
        q: 'Parameter yang menunjukkan jumlah oksigen yang tersedia bagi ikan disebut?',
        options: ['pH', 'Dissolved Oxygen (DO)', 'Amonia'],
        correct: 1
      },
      {
        q: 'Kisaran pH air yang ideal untuk sebagian besar ikan air tawar adalah?',
        options: ['3,0–5,0', '6,5–8,5', '9,5–11,0'],
        correct: 1
      },
      {
        q: 'Salah satu penyebab utama tingginya kadar amonia di kolam adalah?',
        options: ['Sisa pakan yang menumpuk', 'Air yang sering diganti', 'Aerasi yang aktif'],
        correct: 0
      }
    ]
  },
  {
    id: 3,
    seq: '03',
    title: 'Pembenihan Ikan Nila',
    summary: 'Tahapan pemijahan, penetasan telur, hingga perawatan larva di bak benih.',
    description: 'Tahapan pemijahan, penetasan telur, hingga perawatan larva di bak benih.',
    sessions: 5,
    duration: '40 menit',
    xp: 90,
    status: 'terkunci',
    gradient: 'linear-gradient(135deg, #F5C97A, #E8A23A)',
    content: [
      'Ikan nila termasuk jenis ikan yang mengerami telurnya di dalam mulut induk betina (mouth brooder), berbeda dengan kebanyakan ikan air tawar lain yang menempelkan telur di substrat.',
      'Proses pemijahan biasanya menggunakan rasio induk jantan dan betina sekitar 1:3, dengan induk yang sudah matang gonad (siap kawin) ditandai perut membesar pada betina dan warna tubuh lebih cerah pada jantan.',
      'Suhu air pada kisaran 27–30°C mempercepat proses penetasan telur, yang umumnya menetas dalam 3–5 hari setelah pembuahan.',
      'Setelah menetas, larva memerlukan pakan alami berukuran sangat kecil seperti naupli artemia atau infusoria selama beberapa hari pertama, sebelum beralih ke pakan buatan (pelet halus).'
    ],
    questions: [
      {
        q: 'Ikan nila termasuk jenis ikan yang mengerami telurnya di mana?',
        options: ['Menempel pada substrat dasar kolam', 'Di dalam mulut induk betina', 'Mengapung bebas di permukaan air'],
        correct: 1
      },
      {
        q: 'Suhu air yang mempercepat proses penetasan telur nila berada pada kisaran?',
        options: ['18–20°C', '27–30°C', '35–38°C'],
        correct: 1
      },
      {
        q: 'Pakan yang cocok diberikan pada larva nila di hari-hari pertama adalah?',
        options: ['Pelet ukuran besar', 'Naupli artemia/infusoria', 'Dedak kasar'],
        correct: 1
      }
    ]
  },
  {
    id: 4,
    seq: '04',
    title: 'Manajemen Pakan Ikan',
    summary: 'Menghitung dosis pakan, jadwal pemberian, dan efisiensi konversi pakan (FCR).',
    description: 'Menghitung dosis pakan, jadwal pemberian, dan efisiensi konversi pakan (FCR).',
    sessions: 4,
    duration: '30 menit',
    xp: 70,
    status: 'terkunci',
    gradient: 'linear-gradient(135deg, #5D7C8A, #0E4C6B)',
    content: [
      'Pakan merupakan komponen biaya terbesar dalam budidaya, sehingga pemberiannya perlu diperhitungkan agar efisien namun tetap mencukupi kebutuhan pertumbuhan ikan.',
      'Dosis pakan harian umumnya diberikan sebesar 3–5% dari total berat biomassa ikan di kolam, dibagi dalam 2–3 kali pemberian per hari.',
      'Feed Conversion Ratio (FCR) adalah ukuran efisiensi pakan — yaitu jumlah pakan (kg) yang dibutuhkan untuk menghasilkan 1 kg pertambahan bobot ikan. Semakin rendah nilai FCR, semakin efisien pakan yang digunakan.',
      'Pemberian pakan yang berlebihan tidak mempercepat pertumbuhan, justru menyisakan pakan yang membusuk dan menurunkan kualitas air kolam.'
    ],
    questions: [
      {
        q: 'Nilai FCR (Feed Conversion Ratio) yang baik ditandai dengan angka yang?',
        options: ['Semakin tinggi semakin efisien', 'Semakin rendah semakin efisien', 'Tidak berkaitan dengan efisiensi'],
        correct: 1
      },
      {
        q: 'Dosis pakan harian yang umum diberikan berdasarkan persentase biomassa adalah?',
        options: ['3–5%', '15–20%', '0,5–1%'],
        correct: 0
      },
      {
        q: 'Pemberian pakan yang berlebihan dapat menyebabkan?',
        options: ['Pertumbuhan ikan dua kali lebih cepat', 'Penurunan kualitas air kolam', 'Kadar oksigen otomatis naik'],
        correct: 1
      }
    ]
  },
  {
    id: 5,
    seq: '05',
    title: 'Hama dan Penyakit Ikan',
    summary: 'Mengenali gejala umum, pencegahan, dan penanganan awal di kolam budidaya.',
    description: 'Mengenali gejala umum, pencegahan, dan penanganan awal di kolam budidaya.',
    sessions: 4,
    duration: '34 menit',
    xp: 70,
    status: 'terkunci',
    gradient: 'linear-gradient(135deg, #1C8C8C, #062B44)',
    content: [
      'Gejala umum ikan yang sakit antara lain nafsu makan menurun, muncul luka atau bercak putih pada tubuh, serta pola renang yang tidak normal (menggantung di permukaan atau berputar-putar).',
      'Penyebab umum penyakit meliputi kualitas air yang buruk, kepadatan tebar yang terlalu tinggi, serta infeksi jamur, bakteri, atau parasit yang mudah menyebar dalam kondisi kolam yang padat.',
      'Langkah pencegahan paling mendasar adalah mengarantina benih baru sebelum dicampur dengan populasi lama, menjaga kualitas air tetap stabil, serta menjaga kebersihan (sanitasi) wadah budidaya.'
    ],
    questions: [
      {
        q: 'Langkah pencegahan penyakit paling mendasar sebelum menebar benih baru adalah?',
        options: ['Langsung mencampur dengan populasi lama', 'Mengarantina benih baru terlebih dahulu', 'Menambah dosis pakan'],
        correct: 1
      },
      {
        q: 'Berikut yang termasuk gejala umum ikan sakit adalah?',
        options: ['Nafsu makan meningkat drastis', 'Nafsu makan menurun', 'Warna tubuh semakin cerah'],
        correct: 1
      },
      {
        q: 'Kepadatan tebar yang terlalu tinggi dapat meningkatkan risiko?',
        options: ['Penyebaran penyakit antar ikan', 'Penurunan kebutuhan pakan', 'Peningkatan kadar oksigen'],
        correct: 0
      }
    ]
  },
  {
    id: 6,
    seq: '06',
    title: 'Panen dan Pascapanen',
    summary: 'Teknik panen yang tepat serta penanganan hasil agar mutu tetap terjaga.',
    description: 'Teknik panen yang tepat serta penanganan hasil agar mutu tetap terjaga.',
    sessions: 3,
    duration: '24 menit',
    xp: 60,
    status: 'terkunci',
    gradient: 'linear-gradient(135deg, #0E4C6B, #062B44)',
    content: [
      'Waktu panen ditentukan berdasarkan ukuran atau bobot target yang sudah ditetapkan sejak awal, disesuaikan dengan permintaan pasar.',
      'Panen sebaiknya dilakukan pada pagi atau sore hari saat suhu udara lebih rendah, untuk meminimalkan stres dan risiko kematian ikan selama proses penangkapan.',
      'Penanganan pascapanen meliputi pendinginan cepat (rantai dingin) untuk menjaga kesegaran dan mutu hasil, serta sortasi (pengelompokan) berdasarkan ukuran sebelum dipasarkan.'
    ],
    questions: [
      {
        q: 'Panen sebaiknya dilakukan pada waktu?',
        options: ['Siang hari saat suhu tinggi', 'Pagi atau sore hari saat suhu rendah', 'Tengah malam'],
        correct: 1
      },
      {
        q: 'Tujuan utama penerapan rantai dingin pascapanen adalah?',
        options: ['Menjaga mutu dan kesegaran hasil panen', 'Mempercepat pembusukan', 'Menambah bobot ikan'],
        correct: 0
      },
      {
        q: 'Sortasi pascapanen bertujuan untuk?',
        options: ['Mengelompokkan hasil panen berdasarkan ukuran', 'Mencampur semua ukuran menjadi satu', 'Mengganti jenis ikan'],
        correct: 0
      }
    ]
  }
];
