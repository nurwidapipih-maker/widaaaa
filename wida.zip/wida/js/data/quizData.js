/**
 * Bank Soal Kuis Interaktif Ombak Belajar
 */
export const quizData = [
  {
    id: 1,
    tag: 'SESI 3 · PEMBENIHAN IKAN NILA',
    question: 'Suhu ideal untuk penetasan telur ikan nila berada di kisaran?',
    options: [
      { text: '18–20 °C', isCorrect: false },
      { text: '27–30 °C', isCorrect: true },
      { text: '35–38 °C', isCorrect: false }
    ],
    feedbackCorrect: 'Betul! Suhu 27–30°C mempercepat proses penetasan telur nila tanpa memicu jamur.',
    feedbackWrong: 'Belum tepat — suhu idealnya 27–30°C. Tetap dapat XP karena sudah mencoba!',
    xpReward: 10
  },
  {
    id: 2,
    tag: 'SESI 2 · KUALITAS AIR KOLAM',
    question: 'Berapa batas rentang pH air yang ideal untuk kelangsungan hidup ikan air tawar?',
    options: [
      { text: '3.0 – 5.0 (Sangat Asam)', isCorrect: false },
      { text: '6.5 – 8.5 (Netral Seimbang)', isCorrect: true },
      { text: '10.0 – 12.0 (Sangat Basa)', isCorrect: false }
    ],
    feedbackCorrect: 'Tepat sekali! Rentang 6.5–8.5 menjaga fungsi insang dan metabolisme ikan tetap prima.',
    feedbackWrong: 'Kurang tepat — pH ideal berkisar 6.5–8.5. Coba ingat kembali di modul kualitas air!',
    xpReward: 10
  },
  {
    id: 3,
    tag: 'SESI 4 · MANAJEMEN PAKAN',
    question: 'Apa arti nilai FCR (Feed Conversion Ratio) yang semakin rendah?',
    options: [
      { text: 'Pemberian pakan semakin boros', isCorrect: false },
      { text: 'Ikan membuang banyak kotoran', isCorrect: false },
      { text: 'Efisiensi pakan semakin tinggi dan hemat', isCorrect: true }
    ],
    feedbackCorrect: 'Luar biasa! FCR rendah berarti pakan yang diubah jadi daging ikan semakin banyak.',
    feedbackWrong: 'Belum tepat — semakin kecil nilai FCR, berarti pakan semakin efisien!',
    xpReward: 10
  }
];
