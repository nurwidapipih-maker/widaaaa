/**
 * Data Papan Peringkat (Leaderboard) Siswa Budidaya Perikanan
 */
export const leaderboardData = [
  {
    rank: 1,
    name: 'Bima Samudera',
    class: 'XI BAP 1',
    completedModules: 5,
    xp: 420,
    isCurrent: false
  },
  {
    rank: 2,
    name: 'Nanda Clarissa',
    class: 'XI BAP 2',
    completedModules: 4,
    xp: 350,
    isCurrent: false
  },
  {
    rank: 3,
    name: 'Rian Pratama (Kamu)',
    class: 'XI BAP 1',
    completedModules: 2,
    xp: 230,
    isCurrent: true
  },
  {
    rank: 4,
    name: 'Dewi Anjani',
    class: 'XI BAP 1',
    completedModules: 2,
    xp: 190,
    isCurrent: false
  },
  {
    rank: 5,
    name: 'Fajar Nugraha',
    class: 'XI BAP 2',
    completedModules: 1,
    xp: 120,
    isCurrent: false
  }
];
