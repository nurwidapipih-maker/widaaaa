# DOKUMENTASI LENGKAP & RIWAYAT PENGEMBANGAN
# OMBAK BELAJAR — BUDIDAYA PERIKANAN SMK KELAS XI

---

## 1. GAMBARAN UMUM PROYEK

**Ombak Belajar** adalah media pembelajaran web interaktif berbasis gamifikasi yang dirancang khusus untuk mata pelajaran **Budidaya Perairan / Perikanan SMK Kelas XI**. Proyek ini dikembangkan dengan arsitektur **Vanilla JavaScript (ES6 Modules) dan Vanilla CSS modular**, tanpa ketergantungan pada framework berat (seperti React atau Vue), sehingga sangat ringan, mudah dipahami strukturnya, transparan, serta ideal untuk penelitian skripsi/R&D (*Research and Development*).

### Spesifikasi Teknis:
- **Teknologi Utama**: HTML5 Semantik, Vanilla CSS (CSS Variables, Flexbox, CSS Grid), Vanilla JavaScript (ES6 Modules).
- **Desain & Tipografi**: Font *Fraunces* (Heading serif klasik edukatif) dan *Space Grotesk* (Body sans-serif modern teknis).
- **Aset Ikon**: 100% SVG Vektor Presisi (Tanpa emoji Unicode pihak ketiga).
- **Penyimpanan Data**: Dual-Engine (Engine 1: LocalStorage Browser; Engine 2: Cloud Firestore Firebase Realtime).
- **ID Proyek Cloud**: `ombak-belajar` (Status: Terhubung Aktif).
- **Panel Pengelolaan**: Admin CMS Mandiri (`admin.html`) dengan 5 tab kendali tanpa perlu koding.

---

## 2. PENJELASAN LENGKAP & INTEGRASI CLOUD FIREBASE

### A. Apa itu Firebase dan Mengapa Digunakan?
**Google Firebase** adalah platform komputasi awan (*cloud computing*) terkelola milik Google. Di dalam aplikasi Ombak Belajar, modul yang digunakan secara spesifik adalah **Cloud Firestore**, yaitu database dokumen NoSQL di server Google yang memiliki fitur pembacaan dan penulisan data secara *real-time*.

Alasan utama penggunaan Firebase Firestore dalam sistem ini:
1. **Arsitektur Serverless (Tanpa Backend Rumit)**: Kita tidak perlu menyewa VPS atau membuat server backend terpisah (seperti Express.js, Laravel, atau MySQL). Aplikasi web langsung berkomunikasi dengan database Google melalui SDK resmi yang aman.
2. **Sinkronisasi Antar-Perangkat Real-Time**: Ketika siswa A menyelesaikan modul di HP-nya dan memperoleh XP, skor barunya langsung tersimpan ke cloud. Siswa B yang membuka halaman leaderboard di laptopnya akan melihat peringkat siswa A terupdate otomatis tanpa perlu refresh halaman.
3. **Persistensi Data Permanen**: Mengatasi kelemahan memori browser lokal (*localStorage*). Jika siswa berganti ponsel, membersihkan cache browser, atau membuka dari perangkat sekolah, riwayat belajarnya tetap aman di cloud.
4. **Bebas Biaya (Google Spark Free Tier)**: Google menyediakan kuota gratis yang sangat besar (50.000 pembacaan dan 20.000 penulisan per hari) tanpa memerlukan kartu kredit.

---

### B. Arsitektur Dual-Engine: Mode Lokal vs Mode Cloud Firebase

Aplikasi Ombak Belajar menerapkan prinsip *Graceful Degradation* dengan arsitektur Dual-Engine pada `js/state/store.js`:

| Parameter | Mode 1: Mode Lokal (LocalStorage) | Mode 2: Mode Cloud Firebase (Aktif Terpusat) |
| :--- | :--- | :--- |
| **Lokasi Data** | Memori browser HP/Laptop siswa (`localStorage`). | Server cloud Google Firestore terpusat. |
| **Cakupan Siswa** | Terisolasi per perangkat (siswa hanya melihat dirinya). | **Multi-User Realtime**. Seluruh kelas terhubung ke 1 papan peringkat. |
| **Koneksi Internet** | Berjalan offline 100% tanpa internet. | Membutuhkan koneksi internet untuk sinkronisasi. |
| **Ketahanan Data** | Hilang jika cache dibersihkan / ganti browser. | **Permanen**. Data siswa tersimpan aman di server cloud Google. |
| **Peran Sistem** | Cadangan darurat jika internet terputus (*fail-safe*). | **Mesin utama** aplikasi saat online. |

---

### C. Penjelasan Rinci 6 Kredensial Konfigurasi (`firebaseConfig`)

Kredensial proyek tersimpan terpusat di `js/config/firebase-config.js`:

```javascript
window.FIREBASE_CONFIG = {
  apiKey: "AIzaSyB3paunvM2qT-o0HS08xbC2hlvq8jyHx2c",
  authDomain: "ombak-belajar.firebaseapp.com",
  projectId: "ombak-belajar",
  storageBucket: "ombak-belajar.firebasestorage.app",
  messagingSenderId: "169821305056",
  appId: "1:169821305056:web:b684b6e6fadce21bbb3885",
  measurementId: "G-B3VW3MH8D6"
};
```

Berikut fungsi teknis dari setiap kunci:
1. **`apiKey`**: Token unik yang mengautentikasi aplikasi web ke Google API Gateway agar diizinkan mengirim dan meminta data ke proyek `ombak-belajar`.
2. **`authDomain`**: Domain autentikasi resmi dari Firebase (`ombak-belajar.firebaseapp.com`) untuk memvalidasi asal permintaan (*origin verification*).
3. **`projectId`**: Nama identitas unik proyek di infrastruktur Google Cloud (`ombak-belajar`). Digunakan oleh Firestore SDK untuk mengarahkan koneksi ke database yang tepat.
4. **`storageBucket`**: Alamat bucket penyimpanan berkas awan (*Google Cloud Storage*) jika kelak ditambahkan fitur unggah berkas gambar atau PDF materi oleh guru.
5. **`messagingSenderId`**: Nomor ID numerik pengenal perutean pesan untuk layanan Firebase Cloud Messaging (FCM).
6. **`appId`**: ID registrasi unik aplikasi web di Firebase Console, membedakan klien web dengan klien aplikasi Android/iOS.

---

### D. Struktur Skema Data di Firestore (Data Schema)

Di dalam database Firestore, data tersimpan dalam koleksi tunggal bernama `students`:

```text
Koleksi: students
  └── Dokumen ID: "std_1788673024830_a8f9" (ID Unik Siswa)
        ├── id: "std_1788673024830_a8f9"       (String)
        ├── name: "Ahmad Fauzi"                (String: Nama Lengkap Siswa)
        ├── class: "XI AP 1"                   (String: Kelas)
        ├── xp: 450                            (Number: Total Poin XP)
        ├── level: 2                           (Number: Level Kemahiran 1-4)
        ├── completed: [1, 2]                  (Array: Nomor Modul yang Selesai)
        ├── registeredAt: "2026-09-06T..."    (String: Waktu Pertama Daftar)
        └── lastActive: "2026-09-06T..."      (String: Waktu Terakhir Belajar)
```

---

### E. Alur Implementasi Kode Teknis

1. **Pemuatan SDK (`index.html` & `admin.html`)**:
   Memuat skrip CDN Firebase Compat v10.12.2:
   ```html
   <script src="https://www.gstatic.com/firebasejs/10.12.2/firebase-app-compat.js"></script>
   <script src="https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore-compat.js"></script>
   <script src="js/config/firebase-config.js"></script>
   ```
2. **Inisialisasi Otomatis (`store.js` -> `initFirebase()`)**:
   Mengecek `window.FIREBASE_CONFIG`. Jika ada, menjalankan `firebase.initializeApp(config)` dan `this.db = firebase.firestore()`. Status `this.firebaseActive` diset ke `true`.
3. **Penyimpanan Siswa (`saveStudentToStorage()`)**:
   Memanggil `this.db.collection('students').doc(studentId).set(studentData, { merge: true })`. Opsi `merge: true` mencegah tertimpanya field yang sudah ada.
4. **Pembaruan Leaderboard Real-Time (`fetchFirebaseLeaderboard()`)**:
   Menjalankan query: `this.db.collection('students').orderBy('xp', 'desc').limit(10).get()`. Mengambil 10 siswa dengan XP tertinggi dan otomatis merender medali juara.
5. **Fail-Safe Offline Fallback**:
   Jika siswa kehilangan sinyal internet saat belajar, blok `try...catch` otomatis mengalihkan penyimpanan ke `localStorage` sehingga aplikasi tidak mengalami *freeze* atau *crash*.

---

### F. Aturan Keamanan Firestore (Security Rules)

Database dikonfigurasi dalam *Test Mode* agar siswa dapat langsung mengakses media tanpa formulir pembuatan akun dan kata sandi yang rumit:
```javascript
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /students/{studentId} {
      allow read, write: if true;
    }
  }
}
```

---

## 3. KRONOLOGI PERUBAHAN & EVOLUSI DARI AWAL PEMBUATAN

Proyek ini telah mengalami serangkaian transformasi besar dari tahap awal hingga mencapai arsitektur siap pakai kelas produksi:

### Fase 1: File Awal Monolitik (Titik Awal)
* **Kondisi Awal**: Proyek dimulai dari dua file HTML monolitik raksasa:
  1. `prototype_ombak_belajar.html` (~20 KB): Fokus pada prototipe tata letak antarmuka.
  2. `ombak_belajar_fungsional.html` (~30 KB): Mengandung seluruh kode HTML, CSS (~600 baris), dan JavaScript (~700 baris) yang dicampur aduk dalam satu file tunggal.
* **Tantangan**: Kode monolitik sulit dirawat (*spaghetti code*), perubahan desain berisiko merusak logika, dan materi pelajaran tertanam mati (*hardcoded*) di dalam script sehingga guru tidak dapat mengedit konten.

### Fase 2: Refaktorisasi Total ke Arsitektur Modular
* **Langkah Kerja**:
  - Memisahkan kode HTML menjadi kerangka semantik di `index.html` dengan konsep *mount points* (`<div id="hero-mount">`, dsb.).
  - Memecah CSS monolitik menjadi 11 file terpisah dalam folder `css/` dan `css/components/` dengan arsitektur Design Tokens (`variables.css`) dan BEM (*Block Element Modifier*).
  - Memecah logika JavaScript menjadi komponen-komponen terisolasi di folder `js/components/` yang dihubungkan melalui *Central Reactive Store* (`js/state/store.js`).
* **Hasil**: Kode menjadi bersih, setiap komponen memiliki tanggung jawab tunggal (*Single Responsibility Principle*), dan kecepatan render tetap maksimal.

### Fase 3: Pembangunan Panel Guru (Admin CMS)
* **Kebutuhan**: Guru mata pelajaran harus bisa menambah materi, memperbarui kuis, atau melihat siswa tanpa harus mengutak-atik kode program.
* **Implementasi**: Diciptakan halaman mandiri `admin.html` beserta kontrolernya `js/admin.js` yang menyediakan 5 tab:
  1. Tab Modul Pembelajaran (CRUD materi, paragraf, dan soal evaluasi).
  2. Tab Bank Soal Kuis Beranda.
  3. Tab Papan Peringkat Siswa.
  4. Tab Kustomisasi Teks Beranda (Hero, Why, CTA, Footer).
  5. Tab Pengaturan Integrasi Database & Profil Simulasi.

### Fase 4: Standardisasi Visual Bebas Emoji (SVG Only)
* **Kebutuhan**: Menghilangkan seluruh karakter emoji Unicode bawaan sistem operasi (seperti 🌊, 🐟, 🏆, 👋, ✕) yang tampilannya berbeda-beda di tiap merk HP/laptop dan terkesan tidak formal.
* **Implementasi**: 
  - Seluruh emoji dibersihkan dari HTML, CSS, dan JavaScript data.
  - Dibangun modul `js/utils/icons.js` berisi fungsi pembentuk SVG vektor presisi dengan warna tema seragam (Teal `#1C8C8C`, Mint `#7FE0C9`, Navy `#0D233A`).

### Fase 5: Penyempurnaan UX, Spacing, dan Evaluasi Modul Multi-Soal
* **Kebutuhan**:
  - Jarak (*spacing*) antara navbar, hero, dan badge modul awal terlalu mepet.
  - Modul harus menyediakan materi edukatif mendalam dan kuis evaluasi kelulusan.
* **Implementasi**:
  - Perbaikan layout CSS dengan menambahkan `padding-top: 104px` pada `.modules` agar posisi kartu tidak tertutup navigasi mengambang.
  - Penggabungan materi multi-paragraf (4 paragraf per modul) dan 3 soal evaluasi per modul dengan syarat kelulusan (*passing grade*) minimal 60%.
  - Implementasi fitur *Sequential Unlock*: Modul ke-2 baru akan terbuka jika modul ke-1 sudah lulus dikerjakan.

### Fase 6: Transformasi Papan Peringkat (Dari Data Fiktif ke Siswa Riil)
* **Kondisi Sebelumnya**: Papan peringkat awal diisi oleh data dummy buatan (nama fiktif seperti "Budi Santoso", "Siti Rahma").
* **Permintaan Pengguna**: Nama di papan peringkat harus murni berasal dari siswa riil yang mengetikkan namanya saat pertama kali membuka web.
* **Implementasi**:
  - Mengubah fungsi `buildLeaderboardFromRegistry()` pada `store.js`.
  - Data dummy dihapus. Ketika siswa mendaftar lewat *Name Gate* (`NameGate.js`), data siswa langsung didaftarkan ke sistem `student_registry`.
  - Papan peringkat meranking siswa nyata berdasarkan perolehan XP dan modul yang berhasil diselesaikan secara otomatis.

### Fase 7: Integrasi Cloud Firebase Firestore (Sinkronisasi Multi-Perangkat)
* **Kondisi Sebelumnya**: Mode lokal hanya menyimpan data di memori browser perangkat masing-masing (`localStorage`). Siswa di HP yang berbeda tidak bisa saling melihat di papan peringkat.
* **Implementasi**:
  - Dibuat koneksi ke database Google Firebase Firestore melalui `js/config/firebase-config.js` yang terhubung ke proyek cloud `ombak-belajar`.
  - Skrip `store.js` dan `admin.js` diperbarui agar otomatis mengaktifkan mode Cloud Sync secara global.
  - Setiap siswa yang mendaftar atau menjawab kuis akan mengirimkan data langsung ke koleksi `students` di Firestore, sehingga seluruh kelas dapat melihat skor satu sama lain secara real-time.

### Fase 8: Versioning Git, GitHub & Kesiapan Deploy Vercel
* **Implementasi**:
  - Inisialisasi Git repository lokal.
  - Penghubungan remote dan publikasi repositori ke GitHub: [hasbyash05/wida](https://github.com/hasbyash05/wida).
  - Proyek siap dihubungkan ke Vercel untuk hosting publik otomatis dengan satu klik.

---

## 4. STRUKTUR FILE & FUNGSI SETIAP KOMPONEN

```
d:\WEB\wida\
├── index.html                     # Halaman utama aplikasi untuk siswa
├── admin.html                     # Panel Guru / CMS Pengelolaan Konten
├── package.json                   # Konfigurasi npm dev script
├── README.md                      # Ringkasan proyek & panduan cepat
├── DOKUMENTASI.md                 # Dokumen teknis komprehensif ini
├── DOKUMENTASI_OMBAK_BELAJAR_LENGKAP.docx  # Versi Microsoft Word siap cetak
│
├── css/
│   ├── main.css                   # Induk stylesheet (mengimpor semua berkas CSS)
│   ├── variables.css              # Design tokens (warna HSL, radius, shadow, font)
│   ├── base.css                   # Reset browser, layout container, utilitas
│   ├── admin.css                  # Gaya visual khusus untuk dashboard CMS admin
│   └── components/
│       ├── navbar.css             # Desain navigasi melayang & badge profil siswa
│       ├── hero.css               # Desain header sambutan & ringkasan progres
│       ├── why.css                # Desain 3 kartu pilar keunggulan materi
│       ├── modules.css            # Desain grid 6 kartu modul & badge status kunci
│       ├── modal.css              # Desain popup dialog materi belajar & kuis modul
│       ├── quiz.css               # Desain kuis interaktif beranda & kotak umpan balik
│       ├── leaderboard.css        # Desain tabel papan peringkat & medali juara
│       └── cta-footer.css         # Desain banner ajakan & footer halaman
│
└── js/
    ├── app.js                     # Entry point JavaScript: inisialisasi & render komponen
    ├── admin.js                   # Kontroler logika dashboard CMS admin
    │
    ├── config/
    │   └── firebase-config.js     # Kunci kredensial Cloud Firestore terpusat
    │
    ├── utils/
    │   └── icons.js               # Generator ikon SVG vektor presisi (Bebas Emoji)
    │
    ├── data/
    │   ├── modulesData.js         # Data kurikulum 6 modul materi & 18 butir soal evaluasi
    │   ├── quizData.js            # Bank soal kuis cepat interaktif beranda
    │   ├── leaderboardData.js     # Konfigurasi awal peringkat
    │   └── siteContentData.js     # Teks konten statis beranda (Hero, Why, CTA, Footer)
    │
    ├── state/
    │   └── store.js               # Central State Manager: reaktivitas, XP, & penyimpanan
    │
    └── components/
        ├── NameGate.js            # Komponen onboarding nama & kelas siswa
        ├── Navbar.js              # Navigasi atas & widget XP/Level siswa
        ├── Hero.js                # Tampilan hero banner & statistik progres
        ├── WhySection.js          # Seksi 3 pilar keunggulan budidaya perikanan
        ├── ModulesSection.js      # Seksi grid kartu materi belajar
        ├── ModuleModal.js         # Dialog interaktif: baca materi 4 bab & evaluasi kelulusan
        ├── QuizSection.js         # Kuis interaktif beranda dengan umpan balik langsung
        ├── LeaderboardSection.js  # Papan peringkat real-time siswa
        ├── CtaSection.js          # Banner motivasi belajar
        └── Footer.js              # Footer navigasi & akses cepat ke CMS Guru
```

---

## 5. PANDUAN PENGOPERASIAN & DEPLOYMENT

### Menjalankan di Komputer Lokal (Development)
Website ini menggunakan JavaScript ES6 Modules, sehingga memerlukan *web server* lokal (tidak boleh dibuka langsung via klik ganda file `file:///`):
1. Buka terminal di folder proyek (`d:\WEB\wida`).
2. Jalankan perintah:
   ```bash
   npx -y serve . -l 3000
   ```
   *atau menggunakan Python bawaan:*
   ```bash
   python -m http.server 3000
   ```
3. Buka browser di alamat: `http://localhost:3000`.

### Mengelola Konten (Untuk Guru)
- Buka `http://localhost:3000/admin.html` (atau klik tombol **Panel Guru CMS** di footer website).
- Seluruh perubahan yang disimpan di halaman admin akan langsung aktif dan terlihat di halaman siswa.

### Sinkronisasi ke GitHub
Setiap kali ada perubahan kode:
```bash
git add .
git commit -m "Deskripsi perubahan"
git push origin master
```
Repositori GitHub: [https://github.com/hasbyash05/wida](https://github.com/hasbyash05/wida)

### Deploy Live ke Vercel (Hosting Publik Gratis)
1. Kunjungi [vercel.com](https://vercel.com) dan login menggunakan akun GitHub Anda.
2. Klik **Add New...** ➜ **Project**.
3. Pilih repositori **hasbyash05/wida**, lalu klik **Import**.
4. Biarkan konfigurasi standar (*Framework Preset: Other / Static*).
5. Klik **Deploy**.
6. Website live publik Anda (misal `https://wida.vercel.app`) siap dibagikan kepada seluruh siswa.
